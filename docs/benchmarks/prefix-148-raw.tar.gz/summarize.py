import csv
import json
import re
from collections import defaultdict
from pathlib import Path
from statistics import median

root = Path(__file__).resolve().parent
final = root/'decision'
stages = root/'raw'
groups = defaultdict(list)
def bench(f, stage, round):
    lines = f.read_text().splitlines()
    assert 'PASS' in lines, f
    for l in lines:
        if not l.startswith('Benchmark'):
            continue
        case, n, *values = l.split()
        parts = case.split('/')
        if parts[0]=='BenchmarkEdgePrefix':
            _,mode,layout,op,q,arm = parts
            fam='raw'
        elif parts[0]=='BenchmarkTypedEdgePrefix':
            _,mode,op,arm=parts
            layout,q,fam='interleaved','medium','typed'
        elif parts[0]=='BenchmarkEdgePrefixWorkingSet':
            _,budget,op,arm=parts
            mode,layout,q,fam='BTree','interleaved',budget,'rotate'
            assert int(n)==256
        else:
            raise ValueError(case)
        v={k: float(x) for x,k in zip(values[::2],values[1::2])}
        if fam=='raw':
            assert v['matches/op']=={'missing':0,'sparse':1,'medium':56,'broad':2048,'first':1,'empty':16385}[q], case
        if fam=='typed':
            assert v['matches/op']==56
        groups[(stage, fam, mode, layout, op, q, arm)].append((round, v))

for f in sorted(stages.glob('*-prefix-[123].txt')):
    name, arm, rnd=f.stem.split('-')
    if name not in ('v1','v2','v2mem','v3','v3mem','w8','w32','w64','v4','s256','s512','s1024'):
        continue
    bench(f,name,int(rnd))
for f in sorted(final.glob('r*-*.txt')):
    m=re.fullmatch(r'r(\d+)-(filter|prefix)-(raw|typed|working-set)\.txt',f.name)
    assert m, f
    bench(f,'decision',int(m[1]))
for arm in ('filter','prefix'):
    f=final/f'io-{arm}.jsonl'
    rows=[json.loads(l) for l in f.read_text().splitlines()]
    assert len(rows)==24
    for r in rows:
        assert r['full_read_control_bytes']>0 and r['data_files']>1 and r['matches']=={'medium':56,'broad':2048}[r['query']]
        groups['decision','evicted','BTree',r['layout'],r['operation'],r['query'],arm].append((r['trial'],{'ns/op':r['elapsed_ns'],'read-bytes/op':r['process_read_bytes'],'matches/op':r['matches'],'yielded/op':r['yielded'],'yielded-value-B/op':r['yielded_value_bytes']}))

metrics=['ns/op','B/op','allocs/op','matches/op','yielded/op','yielded-value-B/op','typed-yields/op','index-page-reads/op','index-leaf-reads/op','read-bytes/op']
def number(n): return format(n,'.10g')
out=root/'prefix-148.csv'
with out.open('w',newline='') as file:
    w=csv.writer(file, lineterminator="\n")
    w.writerow(['series','workload','index','layout','iterator','query','arm','samples','min-ns/op','max-ns/op']+['median-'+m for m in metrics])
    for k,samples in sorted(groups.items()):
        rounds,vals=zip(*samples)
        assert sorted(rounds)==[1,2,3], (k,rounds)
        ns=[v['ns/op'] for v in vals]
        w.writerow([*k,len(rounds),number(min(ns)),number(max(ns))]+[number(median(v[m] for v in vals)) if m in vals[0] else '' for m in metrics])
assert sum(len(v) for k,v in groups.items() if k[0]=='decision')==384
for layout in ('grouped','interleaved'):
    pairs=[json.loads(l) for f in final.glob('io-*.jsonl') for l in f.read_text().splitlines() if json.loads(l)['layout']==layout]
    assert len({(r['database_id'],r['sequence']) for r in pairs})==1
print(out, len(groups), 'rows')
