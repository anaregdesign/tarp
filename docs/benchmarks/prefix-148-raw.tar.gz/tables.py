import csv,json
from pathlib import Path
from statistics import median
p=Path(__file__).resolve().parent
rows=list(csv.DictReader((p/'prefix-148.csv').open()))
def row(series,work,mode,layout,op,q,arm):
    found=[r for r in rows if (r['series'],r['workload'],r['index'],r['layout'],r['iterator'],r['query'],r['arm'])==(series,work,mode,layout,op,q,arm)]
    assert len(found)==1,(series,work,mode,layout,op,q,arm)
    return found[0]
def fmt(n):
    if n<10: return f'{n:.2f}'
    if n<100: return f'{n:.1f}'
    return f'{n:,.0f}'
def duration(ns):
    if ns<1e6: return fmt(ns/1e3)+' µs'
    return fmt(ns/1e6)+' ms'
def ns(r): return float(r['median-ns/op'])
def summary(work,mode,layout,op,q):
    a,b=(row('decision',work,mode,layout,op,q,arm) for arm in ('filter','prefix'))
    return duration(ns(a)),duration(ns(b)),fmt(ns(a)/ns(b))+'×'
def emit(*cells): print('| '+' | '.join(cells)+' |')
def header(*cells): emit(*cells); emit(*(['---']*len(cells)))
header('Index','Case','Keys + filter','KeysPrefix','Ratio','Scan + filter','ScanPrefix','Ratio')
for mode in ('BTree','Memory'):
 for q in ('missing','sparse','medium','broad','first','empty'):
    emit(mode,q,*summary('raw',mode,'interleaved','Keys',q),*summary('raw',mode,'interleaved','Scan',q))
print()
header('Index','Iterator','Filter','Prefix','Ratio','Filter allocations','Prefix allocations')
for mode in ('BTree','Memory'):
 for op in ('Keys','Scan'):
    arms=[row('decision','typed',mode,'interleaved',op,'medium',arm) for arm in ('filter','prefix')]
    emit(mode,op,*summary('typed',mode,'interleaved',op,'medium'),*[fmt(float(r['median-allocs/op'])) for r in arms])
print()
header('Budget','Iterator','Filter','Prefix','Ratio','Filter page reads/query','Prefix page reads/query')
for q in ('1MiB','16MiB'):
 for op in ('Keys','Scan'):
    arms=[row('decision','rotate','BTree','interleaved',op,q,arm) for arm in ('filter','prefix')]
    emit(q,op,*summary('rotate','BTree','interleaved',op,q),*[fmt(float(r['median-index-page-reads/op'])) for r in arms])
print()
header('Write order','Matches','Scan + filter','ScanPrefix','Ratio','Filter read KiB','Prefix read KiB')
for layout in ('grouped','interleaved'):
 for q,m in (('medium','56'),('broad','2,048')):
    a,b=(row('decision','evicted','BTree',layout,'Scan',q,arm) for arm in ('filter','prefix'))
    emit(layout,m,duration(ns(a)),duration(ns(b)),fmt(ns(a)/ns(b))+'×',fmt(float(a['median-read-bytes/op'])/1024),fmt(float(b['median-read-bytes/op'])/1024))
print()
header('B+tree version','1 key','56 keys','2,048 keys','2,048 key allocations','2,048 values')
for stage in ('v1','v2','v3','v4'):
 def get(op,q):return row(stage,'raw','BTree','interleaved',op,q,'prefix')
 emit(stage,*[duration(ns(get('Keys',q))) for q in ('sparse','medium','broad')],fmt(float(get('Keys','broad')['median-allocs/op'])),duration(ns(get('Scan','broad'))))
print()
header('Memory version','56 keys','Bytes / 56 keys','2,048 keys','Bytes / 2,048 keys','First of 2,048')
for stage in ('v1','v2mem','v3mem','v4'):
 def get(q):return row(stage,'raw','Memory','interleaved','Keys',q,'prefix')
 emit(stage,duration(ns(get('medium'))),fmt(float(get('medium')['median-B/op'])),duration(ns(get('broad'))),fmt(float(get('broad')['median-B/op'])),duration(ns(get('first'))))
print()
header('Tuning variant','First key','56 keys','2,048 keys','2,048 values')
for stage in ('w8','v3','w32','w64','s256','s512','s1024'):
 def get(op,q):return row(stage,'raw','BTree','interleaved',op,q,'prefix')
 emit(stage,duration(ns(get('Keys','first'))),duration(ns(get('Keys','medium'))),duration(ns(get('Keys','broad'))),duration(ns(get('Scan','broad'))))
