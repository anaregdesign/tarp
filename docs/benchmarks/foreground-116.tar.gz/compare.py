#!/usr/bin/env python3
"""Summarize matched FG116 API measurements using Python's standard library."""

import argparse
import csv
import json
import math
import re
import sys
from collections import defaultdict
from pathlib import Path
from statistics import median


HERE = Path(__file__).resolve().parent
FILE_NAME = re.compile(r"(.+)-(base|trial)-([1-9][0-9]*)\.log")


def read_log(path, require_pass):
    rows = {}
    passed = False
    for i, line in enumerate(path.read_text().splitlines(), 1):
        if line == "PASS":
            passed = True
        if line == "FAIL" or line.startswith("--- FAIL:"):
            raise ValueError(f"{path}:{i}: failed test")
        if not line.startswith("FG116 "):
            continue
        try:
            row = json.loads(line[6:])
            name = row["Name"]
            if not isinstance(name, str) or not name.strip() or name in rows:
                raise ValueError(f"invalid or duplicate workload {name!r}")
            if type(row["N"]) is not int or row["N"] <= 0:
                raise ValueError("invalid N")
            if type(row["ReadBytes"]) is not int or row["ReadBytes"] < 0:
                raise ValueError("invalid ReadBytes")
            for key in ("Ns", "P50", "P99", "Bytes", "Allocs"):
                value = row[key]
                if type(value) not in (int, float) or not math.isfinite(value) or value < 0:
                    raise ValueError(f"invalid {key}")
            if row["Ns"] == 0 or row["P99"] == 0 or row["P50"] > row["P99"]:
                raise ValueError("invalid latency or percentile order")
        except (KeyError, ValueError, TypeError, OverflowError) as exc:
            raise ValueError(f"{path}:{i}: {exc}") from exc
        rows[name] = row
    if not rows or (require_pass and not passed):
        raise ValueError(f"{path}: missing FG116 rows or required PASS marker")
    return rows


def summarize(candidate, paths, rounds, require_pass):
    expected = set(range(1, (rounds or max(paths)) + 1))
    if set(paths) != expected:
        raise ValueError(f"{candidate}: expected rounds {sorted(expected)}, got {sorted(paths)}")
    reference = None
    samples = defaultdict(list)
    for r in sorted(paths):
        if set(paths[r]) != {"base", "trial"}:
            raise ValueError(f"{candidate}: incomplete round {r}, found {sorted(paths[r])}")
        arms = {}
        for arm in ("base", "trial"):
            path = paths[r][arm]
            arms[arm] = read_log(path, require_pass)
            sizes = {name: row["N"] for name, row in arms[arm].items()}
            if reference is None:
                reference = sizes
            if sizes != reference:
                missing = sorted(reference.keys() - sizes.keys())
                extra = sorted(sizes.keys() - reference.keys())
                changed = sorted(k for k in sizes.keys() & reference.keys() if sizes[k] != reference[k])
                raise ValueError(f"{path}: mismatched workloads/N, missing={missing}, extra={extra}, changed N={changed}")
        for name, base in arms["base"].items():
            samples[name].append((base, arms["trial"][name]))
    for name, pair in sorted(samples.items()):
        row = dict(candidate=candidate, workload=name, calls_per_arm_per_round=reference[name], pairs=len(pair))
        for key, label in (("Ns", "mean_ns"), ("P50", "p50_ns"), ("P99", "p99_ns"), ("Bytes", "bytes_per_call"), ("Allocs", "allocs_per_call"), ("ReadBytes", "process_read_bytes_per_round")):
            row[f"base_{label}"] = median(b[key] for b, _ in pair)
            row[f"trial_{label}"] = median(t[key] for _, t in pair)
        row["paired_throughput_pct"] = median(100 * (b["Ns"] / t["Ns"] - 1) for b, t in pair)
        row["throughput_wins"] = sum(t["Ns"] < b["Ns"] for b, t in pair)
        row["paired_p99_pct"] = median(100 * (t["P99"] / b["P99"] - 1) for b, t in pair)
        row["p99_wins"] = sum(t["P99"] < b["P99"] for b, t in pair)
        for key, label in (("Ns", "mean_ns"), ("Bytes", "bytes_per_call"), ("Allocs", "allocs_per_call")):
            row[f"paired_delta_{label}"] = median(t[key] - b[key] for b, t in pair)
        yield row


def table(rows):
    print("| Candidate | Workload | Mean ns/call base → trial | Throughput Δ (wins) | p99 Δ (wins) | Δ B/call | Δ allocs/call |")
    print("|---|---|---:|---:|---:|---:|---:|")
    for r in rows:
        print("| {candidate} | {workload} | {base_mean_ns:,.1f} → {trial_mean_ns:,.1f} | "
              "{paired_throughput_pct:+.1f}% ({throughput_wins}/{pairs}) | {paired_p99_pct:+.1f}% "
              "({p99_wins}/{pairs}) | {paired_delta_bytes_per_call:+.2f} | {paired_delta_allocs_per_call:+.3f} |".format(**r))
    print("\nMedians across paired rounds. Higher throughput and lower p99 win. Ties count as zero wins.")


def main():
    parser = argparse.ArgumentParser(description=__doc__, epilog="Example: python3 compare.py large btree --rounds 6 --require-pass --csv comparison.csv")
    parser.add_argument("candidates", nargs="*", help="candidate names (default: all matched logs)")
    parser.add_argument("--logs", type=Path, default=HERE / "logs", help="directory of <candidate>-{base,trial}-<round>.log")
    parser.add_argument("--rounds", type=int, help="require exactly this many paired rounds, starting at 1")
    parser.add_argument("--require-pass", action="store_true", help="require a Go test PASS line in each log")
    parser.add_argument("--csv", type=Path, help="write the full numeric table to this CSV; use - for CSV only on stdout")
    args = parser.parse_args()
    if args.rounds is not None and args.rounds < 1:
        parser.error("--rounds must be positive")
    groups = defaultdict(lambda: defaultdict(dict))
    try:
        for path in args.logs.iterdir():
            match = FILE_NAME.fullmatch(path.name)
            if match and (not args.candidates or match[1] in args.candidates):
                groups[match[1]][int(match[3])][match[2]] = path
        missing = set(args.candidates) - groups.keys()
        if missing or not groups:
            raise ValueError(f"no matching logs for {sorted(missing) or args.logs}")
        rows = [item for candidate in sorted(groups) for item in summarize(candidate, groups[candidate], args.rounds, args.require_pass)]
        if args.csv:
            if str(args.csv) == "-":
                writer = csv.DictWriter(sys.stdout, fieldnames=rows[0], lineterminator="\n")
                writer.writeheader()
                writer.writerows(rows)
                return
            with args.csv.open("w", newline="") as out:
                writer = csv.DictWriter(out, fieldnames=rows[0])
                writer.writeheader()
                writer.writerows(rows)
        table(rows)
    except (OSError, ValueError) as exc:
        parser.exit(1, f"compare: {exc}\n")


if __name__ == "__main__":
    main()
