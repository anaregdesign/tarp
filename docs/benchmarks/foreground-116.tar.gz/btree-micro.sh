#!/usr/bin/env bash
# build compiles the historical 114 index-only driver; run times an independent
# six-pair campaign. Its output lives outside the FG116 public API logs.
set -euo pipefail
out=$(cd "$(dirname "$0")" && pwd)
repo=${TARP_REPOSITORY:-$(git rev-parse --show-toplevel)}
revision=357e758d95a0646ab6c53f2cde3498f0a05501c1
image=$(cat "$out/image")
common=(--rm --platform linux/arm64 --cpus 4 --network none -e GOMAXPROCS=4)

case "${1:-}" in
build)
    tmp=$(mktemp -d)
    trap 'rm -rf "$tmp"' EXIT
    mkdir -p "$out/bins" "$out/btree-micro"
    for arm in base trial; do
        src="$tmp/$arm"
        mkdir "$src"
        git -C "$repo" archive "$revision" | tar -xf - -C "$src"
        if [[ "$arm" == trial ]]; then
            (cd "$src" && git apply "$out/patches/btree.patch")
        fi
        python3 - "$out/drivers/btree_micro.go.in" "$src/benchmark/issue114_benchmark_test.go" <<'PY'
from pathlib import Path
import sys
template, dest = map(Path, sys.argv[1:])
data = template.read_text()
if data.count("MUTATION") != 1:
    raise ValueError("unexpected benchmark template")
dest.write_text(data.replace("MUTATION", 'old,found,err:=tx.Apply(index.Mutation{Key:key,Delete:op=="delete",Address:next})'))
PY
        docker run "${common[@]}" -e GOTOOLCHAIN=local -e GOPROXY=off \
          --mount type=volume,src=tarp-116-buildcache,dst=/root/.cache/go-build \
          -v "$src:/src:ro" -v "$out/bins:/out" -w /src "$image" \
          go test -buildvcs=false -c -o "/out/btree-micro-$arm" ./benchmark
    done
    (cd "$out" && shasum -a 256 drivers/btree_micro.go.in patches/btree.patch bins/btree-micro-{base,trial}) > "$out/btree-micro/sha256.txt"
    ;;
run)
    result="${2:-$out/btree-micro/results}"
    test -f "$out/btree-micro/sha256.txt" || { echo 'build the binaries before timing' >&2; exit 1; }
    (cd "$out" && shasum -a 256 -c btree-micro/sha256.txt)
    mkdir -p "$(dirname "$result")"
    mkdir "$result"  # each invocation keeps its own logs
    result=$(cd "$result" && pwd)
    docker run "${common[@]}" --mount type=volume,dst=/data \
      -v "$out/bins:/binout:ro" -v "$result:/logs" -e TMPDIR=/data/tmp -w /data "$image" bash -euo pipefail -c '
        mkdir "$TMPDIR"
        for r in {1..6}; do
            order=(base trial)
            if (( r % 2 == 0 )); then order=(trial base); fi
            for arm in "${order[@]}"; do
                /binout/btree-micro-"$arm" -test.run "^$" -test.bench "^BenchmarkIssue114Mutate$" \
                    -test.benchtime 2048x -test.count 1 -test.benchmem > "/logs/$arm-$r.log"
            done
            echo "btree micro pair $r complete"
        done'
    python3 "$out/btree-micro-summary.py" "$result" | tee "$result/summary.csv"
    ;;
*)
    echo "usage: bash $0 build | run [fresh-results-directory]" >&2
    exit 2
    ;;
esac
