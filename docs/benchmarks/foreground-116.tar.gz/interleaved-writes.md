# Foreground writes, interleaved after every call

Linux arm64, 4 CPUs, one anonymous ext4 volume in the campaign image. Each of six rounds starts separate baseline and final worker processes with independently initialized DBs, 8,192 identical 16-byte keys and 64-byte values, a 4 MiB segment target and a parked cleaner. The caller updates existing keys for Put and BatchPut, then deletes disjoint existing keys. Each case issues 384 calls per arm; every Batch call has 16 records. In each cell baseline and final run consecutively with the same input and never overlap. Which arm goes first flips on every pair of calls and across rounds. Mode and seed order also alternate by round. Times enclose only the public call inside each process, excluding fixture construction, request/reply IPC, verification, and startup. No per-phase timing hooks were added. Each worker checks 1,536 observed commits, 13,056 records, 1,664 surviving keys and unchanged active segment ID. It then closes, reopens and checks all 8,192 key states before the raw samples for this DB pair are accepted.

P50 and p99 in µs are medians of the six per-round statistics. Relative changes use the median within-round ratio (throughput baseline mean / final mean; timing final / baseline). Wins count rounds out of six. Independent rounds are the replication unit; the 384 calls in a round share a filesystem and worker.

| Index | Operation | Throughput change | Wins | p50 µs base → final | p99 µs base → final | p99 change | p99 wins |
|---|---|---:|---:|---:|---:|---:|---:|
| memory | put | +22.3% | 4/6 | 676.6 → 671.1 | 3732.0 → 3412.1 | -17.8% | 4/6 |
| memory | batchput16 | +6.2% | 3/6 | 710.4 → 704.9 | 4233.3 → 3437.0 | -4.7% | 4/6 |
| memory | delete | +19.9% | 4/6 | 668.5 → 669.9 | 3562.0 → 3456.5 | -16.7% | 4/6 |
| memory | batchdelete16 | +1.2% | 3/6 | 738.0 → 745.6 | 3600.4 → 3098.5 | +5.8% | 1/6 |
| btree | put | +10.4% | 4/6 | 754.8 → 716.2 | 3373.3 → 2906.8 | -15.1% | 5/6 |
| btree | batchput16 | +34.2% | 6/6 | 1052.7 → 884.9 | 5013.8 → 3901.5 | -22.4% | 6/6 |
| btree | delete | +3.2% | 3/6 | 797.5 → 795.2 | 3806.8 → 4432.8 | -9.3% | 3/6 |
| btree | batchdelete16 | +4.9% | 3/6 | 959.5 → 945.6 | 5301.7 → 5130.8 | -4.5% | 4/6 |
