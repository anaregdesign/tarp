import csv
import math
import json
from pathlib import Path
from statistics import fmean, median
import sys
out=Path(__file__).resolve().parent
rows={(r['candidate'],r['workload']):r for r in csv.DictReader((out/'comparison.csv').open())}
get=lambda arm,key: rows[(arm,key)]
pct=lambda r,k:f"{float(r[k]):+.1f}%"
def result(mode,operation, suffix,scale,unit):
 r=get('merged',mode+'/'+suffix)
 raw=lambda k:f"{float(r[k])/scale:,.2f}"
 return f"| {mode} | {operation} | {raw('base_mean_ns')} → {raw('trial_mean_ns')} {unit} | {pct(r,'paired_throughput_pct')} ({r['throughput_wins']}/6) | {pct(r,'paired_p99_pct')} ({r['p99_wins']}/6) | {float(r['paired_delta_allocs_per_call']):+.1f} |"
tables=[]
for mode in ['memory','btree']:
 for case in [
  ('Get, repeated cached key','cached/64/8/get-mru',1,'ns'),
  ('Put, overwrite','write/64/8/put',1e6,'ms'),
  ('Delete, existing key','write/64/8/delete',1e6,'ms'),
  ('BatchGet, 32 adjacent DATA records','layout/64/8/adjacent32',1000,'µs'),
  ('BatchGet, 32 scattered DATA records','layout/64/8/scattered32',1000,'µs'),
  ('BatchPut, 16 scattered overwrites','write/64/8/batchput16',1e6,'ms'),
  ('BatchPut, 16 adjacent overwrites','write/64/8/batchput16-adjacent',1e6,'ms'),
  ('BatchDelete, 16 existing keys','write/64/8/batchdelete16',1e6,'ms')]:
  tables.append(result(mode,*case))
tab='\n'.join(tables)
def brief(c,k):
 r=get(c,k)
 return f"{pct(r,'paired_throughput_pct')} throughput ({r['throughput_wins']}/6 pairs), {pct(r,'paired_p99_pct')} p99"
inter_rows=[json.loads(line) for line in (out/'interleaved-writes.jsonl').read_text().splitlines()]
follow=[json.loads(line) for line in (out/'interleaved-confirm-wire.jsonl').read_text().splitlines()]
for r in follow:
 r['round']+=6
 r['base_ns'],r['final_ns']=r['final_ns'],r['base_ns']
inter_rows+=follow
inter=[]
for mode in ('memory','btree'):
 for op in ('put','batchput16','delete','batchdelete16'):
  selected=[r for r in inter_rows if r['mode']==mode and r['operation']==op]
  assert sorted(r['round'] for r in selected)==list(range(1,13))
  means=[]; tails=[]
  for r in selected:
   a,b=r['base_ns'],r['final_ns']
   assert len(a)==len(b)==384
   means.append((fmean(a),fmean(b)))
   tails.append((sorted(a)[math.ceil(len(a)*.99)-1],sorted(b)[math.ceil(len(b)*.99)-1]))
  speed=median(100*(a/b-1) for a,b in means)
  p99=median(100*(b/a-1) for a,b in tails)
  win=sum(b<a for a,b in means)
  tailwin=sum(b<a for a,b in tails)
  times=' → '.join(f'{median(x)/1e6:.3f}' for x in zip(*means))
  inter.append(f'| {mode} | {op} | {times} ms | {speed:+.1f}% ({win}/12) | {p99:+.1f}% ({tailwin}/12) |')
intertable='\n'.join(inter)
report=f'''# Foreground Get, Put, Delete and batch experiments

Five prototypes were measured independently against `357e758`. Three changes shipped together. The integrated comparison below uses the final reviewed code. [Issue #116](https://github.com/anaregdesign/tarp/issues/116) · [Raw logs, individual patches, drivers, checksums and reproduction commands](./foreground-116.tar.gz).

## Integrated public API results

Each mean time is the median of six run means. For every pair we calculated throughput from the inverse of mean ns per call, then took the median of the six percentage differences. We used the same method for the latency percentiles. A win means higher throughput or lower p99. Separate medians and median paired ratios can differ. Relative values compare matching workload and API calls.

| Index | Public operation | Mean time per call, baseline → integrated | Paired throughput (wins) | Paired p99 (wins) | Δ allocations/call |
|---|---|---:|---:|---:|---:|
{tab}

The table uses 64-byte values and a read concurrency limit of 8. For cache misses the working set was explicitly removed from the value cache. Seed order determined physical adjacency. The warm 32-record read cases used 1,600 calls per run. A larger control applied a page-cache eviction advisory before every call. For eight groups of four neighboring keys, that control showed {brief('merged','memory/mixed/gapped-8x4/evict-true')} in Memory mode and {brief('merged','btree/mixed/gapped-8x4/evict-true')} in B+tree mode. Cold sweeps reported Linux process read_bytes.

## Adoption decisions

1. **Large-record header + key read — deferred.** Both implementations reduced a 64 KiB value with a 16-byte key from three logical DATA reads to two. The 8 KiB pool variant delivered {brief('largeconfirm','memory/read/65536/8/advised-batchget16')} for a 16-key Memory batch. A right-sized buffer saved one allocation per key, but the 64 KiB B+tree Get after cache advice showed {brief('largeexact','btree/read/65536/8/advised-get')}. Neither variant delivered a consistent public API gain across 9 KiB and 64 KiB values.
2. **Value LRU — adopted.** A hit on the current head skips relinking. Overwrites reuse the entry and replace its owned key and value, so the Memory index and the LRU can share the latest key allocation. Capacity accounting, eviction order and per-batch duplicate marking remain exact. The isolated, ownership-corrected cache overwrite produced {brief('cachefix','cache/overwrite')} and saved one allocation per cached overwritten key. A public repeated-key Memory Get produced {brief('cachefix','memory/cached/64/8/get-mru')}.
3. **Fixed-width B+tree overwrite — adopted.** The transaction copies the encoded page and patches its address or child pointer, then recalculates the checksum. Published pages and snapshots stay immutable. A separate 16,384-key index test measured median overwrite time of 33.40 → 6.92 µs and 369 → 21 allocations/op. Across the six public 384-call pairs, isolated B+tree Put overwrites showed {brief('btreeconfirm','btree/write/64/8/put')} and scattered BatchPut16 showed {brief('btreeconfirm','btree/write/64/8/batchput16')}. The earlier 128-call test gave {brief('btree','btree/write/64/8/put')} for single Put. Sync time varies substantially across runs.
4. **Reusable directory descriptor — deferred.** This saved an open/close pair and roughly 168 B and three allocations per ordinary commit, at a cost of one permanent descriptor per open database. The longer isolated run showed {brief('dirconfirm','memory/write/64/8/put')} for a Memory Put and {brief('dirconfirm','btree/write/64/8/put')} for a B+tree Put. The tradeoff did not justify changing every open database.
5. **Adjacent BatchGet — adopted for small read plans.** Plan a range only when the first two physical reads are contiguous, the plan has at most 32 descriptors, and every grouped record fits in the same 8 KiB window in one DATA file. Up to 32 small contiguous records then share one range read. Multiple jobs respect the DB-wide concurrency limit. Returned values retain their own storage and each record checks key, sequence and checksum. The first prototype made caller key slices escape on scattered requests. The revised one borrows keys through private result slots. A larger-plan prototype improved throughput but raised p99 on warm 256-key Memory batches. The merged version leaves those plans on the per-record scheduler.

## Call-interleaved durable write control

The process-at-a-time comparison showed slower Memory Delete and BatchDelete and slower single-key B+tree Put in the integrated run. To control for changes in sync latency within a round, two persistent workers opened separately seeded databases on the same ext4 volume. One operation finished before its counterpart began. The first worker alternated on each call and the starting order alternated on each round. A timer inside each worker covered the public API only. Each worker verified committed counts and all 8,192 keys after reopen. Two six-round campaigns measured 384 calls per operation, mode and revision (73,728 timed calls total). The second campaign exchanged the workers’ controller slots on a fresh volume. The table restores the revision labels before calculating the 12 paired differences.

| Index | Public operation | Mean time per call, baseline → integrated | Paired throughput (wins) | Paired p99 (wins) |
|---|---|---:|---:|---:|
{intertable}

The scattered B+tree BatchPut won all 12 throughput comparisons and 11 p99 comparisons. Single Memory Put and Delete showed opposite throughput directions in the two campaigns. Memory BatchDelete throughput was near level (−0.8%); its p99 was 5.7% higher, slower in 8 of 12 pairs. The experiment supports the specific read and B+tree overwrite optimizations, with a remaining tail-latency concern for Memory BatchDelete.

## Prior 16-key write regression

We compared `6c2c3d2` and `357e758` separately with the same hook instrumentation, one writer, a parked cleaner, and exactly 128 timed calls per condition per process. Every sample verified the committed sequence and whether rotation occurred. Each run reopened the database and checked the keys.

For 4 MiB segments and 64 KiB values, the paired mean call time increased 3.6% for BatchPut and 5.0% for BatchDelete without rotation. The median sum of measured sync phases rose from 1.126 to 1.211 ms for Put and from 0.660 to 0.702 ms for Delete. Index staging took about 4 µs, uncontended writer wait under 0.1 µs. With rotation, mean call time fell 5.3% and 2.1%. All four smaller-segment controls were faster on mean. This isolates the sync contribution under a parked cleaner. The earlier live-cleaner result can also include contention.

## Measurement boundary

The campaign started on 2026-11-21 JST with Go 1.27.4 linux/arm64, the latest stable Go then available. Docker Desktop used a private ext4 volume on LinuxKit, with four CPUs and GOMAXPROCS=4. The official image digest for every arm was `sha256:4fa7c968ba93f1635670522dbb01a2c78150443e1385746924566079f36570ea`. Timing arms ran sequentially, alternating order for six matched pairs, with fresh databases under /data. The public write confirmation used 8,192 seeded keys and 384 calls per operation per round. Public write timings include DATA and CURRENT publication. Each process reported its own allocation counters and latency samples. p99 of a short cold sweep can represent only one or two samples, and observed differences across six pairs are descriptive. These are targeted foreground workloads with a single caller and parked cleaner.
'''
Path(sys.argv[1]).write_text(report)
