# Confirmation with reversed worker slots

The second campaign uses the exact same Linux arm64 controller, baseline (357e758), and final (merged.patch) binaries as the first. The Docker command mounts the final binary at /bins/iw-base and the baseline at /bins/iw-final. Both arms independently seed fresh databases with identical keys/values on a new anonymous ext4 volume. The per-call, per-round and process-start order of the actual revisions is therefore inverted relative to the first campaign. The parser verifies the three runtime binary hashes, swaps the two arrays and ordering label, and checks every round and workload matches the opposite original ordering. The archived raw controller output uses the slot names; interleaved-confirm.jsonl uses the actual revision labels.

Each campaign contains six alternating rounds, one serial caller per DB, a parked cleaner, 384 calls per arm per round and 64-byte values. In total there are 4,608 measured calls per arm and workload, 48 worker databases; each passes count checks, then reopens and verifies 8,192 keys. Public API timing excludes IPC. Throughput deltas below use the median of within-round baseline-mean / final-mean minus one; latency deltas use final / baseline minus one. Positive throughput and negative latency indicate improvement. Wins count independent matched rounds.

| Index | Op | Throughput first | Confirmation | Combined (wins) | Paired p50 | p99 first | Confirmation | Combined p99 (wins) |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| memory | put | +22.3% | -14.8% | -7.5% (5/12) | +0.4% | -17.8% | +35.1% | +4.8% (5/12) |
| memory | batchput16 | +6.2% | +7.8% | +7.8% (7/12) | -1.2% | -4.7% | -5.1% | -5.1% (8/12) |
| memory | delete | +19.9% | -9.8% | -7.9% (5/12) | +0.1% | -16.7% | -1.2% | -12.6% (7/12) |
| memory | batchdelete16 | +1.2% | -14.5% | -0.8% (5/12) | +0.2% | +5.7% | +6.7% | +5.7% (4/12) |
| btree | put | +10.4% | -9.9% | +4.0% (6/12) | -2.1% | -15.1% | +8.6% | -4.1% (8/12) |
| btree | batchput16 | +34.2% | +15.4% | +23.0% (12/12) | -16.4% | -22.4% | -11.9% | -20.7% (11/12) |
| btree | delete | +3.2% | +17.2% | +11.8% (8/12) | +0.1% | -9.3% | -2.6% | -2.6% (7/12) |
| btree | batchdelete16 | +4.9% | +1.9% | +1.9% (7/12) | -0.7% | -4.5% | -4.2% | -4.2% (9/12) |
