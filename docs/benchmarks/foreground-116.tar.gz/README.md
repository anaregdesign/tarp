# Foreground API experiments for tarp #116

Run the commands below with this archive extracted on a Docker host, from a checkout of github.com/anaregdesign/tarp that includes both 357e758 and 6c2c3d2. Set TARP_REPO and TARP_REPOSITORY to its absolute path and OUT to the extracted directory. All generated files are written under OUT. Keep existing logs by using a fresh output directory for repetitions. Create OUT/bins and OUT/logs. The build script uses a Docker volume named tarp-116-buildcache. The image file pins the official Go image. Docker must support Linux arm64, 4 CPUs and local private volumes. Each timing arm uses a new benchmark process and new DB fixtures on the ext4 volume. Driver code is standard-library-only.

For the first comparison build a separate test binary for each prototype on 357e758 with the common original driver. Run the following in the checkout, substituting the absolute OUT path.

    export TARP_REPO="$PWD" TARP_REPOSITORY="$PWD"
    export TARP_DRIVER="$OUT/drivers/original_api.go.in"
    "$OUT/build.sh" base
    for arm in large cache btree dirfd; do "$OUT/build.sh" "$arm" "$arm"; done
    "$OUT/measure.sh" large large
    "$OUT/measure.sh" cache lru,writes
    "$OUT/measure.sh" btree writes
    "$OUT/measure.sh" dirfd writes
    unset TARP_DRIVER

For extended measurements use drivers/api_test.go on both arms.

    "$OUT/build.sh" extended
    export TARP_BASE=extended
    "$OUT/build.sh" largeconfirm large
    "$OUT/build.sh" btreeconfirm btree
    "$OUT/build.sh" dirconfirm dirfd
    "$OUT/build.sh" contiguous contiguous
    "$OUT/measure.sh" largeconfirm largeconfirm
    "$OUT/measure.sh" btreeconfirm writeslong
    "$OUT/measure.sh" dirconfirm writeslong
    "$OUT/measure.sh" contiguous contiguous,mixed

To repeat the independent old/current rotation investigation, build diagnosis binaries with drivers/build_diag.sh in the repo and run drivers/run_diag.sh from the archive. Summarize with drivers/summarize_diag.py. This test explicitly verifies published sequence, rotation and reopen, times the same hooks in both old/current commits and keeps the cleaner parked. To repeat the standalone B+tree measurement run btree-micro.sh build, then btree-micro.sh run with a new result directory as second argument. File sha256.txt records the binaries used for this campaign. The standalone tests on 16,384 keys ran 2,048 updates or deletes per round.

Analyze public timings with compare.py --rounds 6 --require-pass --csv comparison.csv, listing the desired candidate names as positional arguments. Each JSON row names the workload, call count, mean execution time, p50, p99 in nanoseconds, allocation bytes and count per call, and process read_bytes per run. Durations in writes include commit sync. One internal probe uses fixed-size cache inputs to measure the LRU directly. Public reads include verification. Read/mixed cases qualify the page cache separately: warm reads call Warm; for read/advised cases Evict runs once per sweep, each key is visited once. Mixed evict-true calls Evict before every timed BatchGet, mixed evict-false does not issue an advisory. read_bytes describes Linux process I/O on the VM. The mixed timer excludes eviction and verification. The baseline includes the same probe and clock overhead. Reported relative throughput is the median of base_mean/trial_mean minus one for paired rounds. p99 is calculated in each process first. No background cleaner or competing writer is active in these comparisons.

Further isolated arms and the selected integration use the extended driver. Compile and run each serially.

    "$OUT/build.sh" contiguous2 contiguous contiguous-v2
    "$OUT/measure.sh" contiguous2 contiguous,mixed
    "$OUT/build.sh" largeexact largeexact
    "$OUT/measure.sh" largeexact largeconfirm
    "$OUT/build.sh" combined combined
    "$OUT/measure.sh" combined lru,contiguous,mixed,writeslong,largeconfirm

patches/combined.patch records the first integration. The previous prototype patches remain independent experiments. The integrated range path permits at most 32 captured read descriptors, shares validation and worker code, and avoids constructing per-I/O hook names. btree-micro/clean is the six-pair standalone campaign run without a build in progress. The general engine and all other commit paths use uninstrumented production code for public API timings.

The initial combination (combined) is a pre-review prototype. A review corrected retained key ownership when reusing an LRU entry. The **merged** binary corresponds to the final production code, includes the reviewed cache and keeps the same 32-descriptor upper bound for grouped reads. To reproduce the final cache-only and integrated comparison:

    "$OUT/build.sh" cachefix cachefix
    "$OUT/measure.sh" cachefix lru,writes
    "$OUT/build.sh" merged merged
    "$OUT/measure.sh" merged lru,contiguous,mixed,writeslong,largeconfirm

The matching patch is patches/merged.patch. All six public API families are exercised in the merged comparison.

The interleaved write control keeps both revisions open and times each call inside its worker. Run drivers/interleave_build.sh, then drivers/interleave_run.sh in a fresh results directory with the sources, image and patches copied here. drivers/interleave_summary.py reads the raw per-call arrays. Separate workers verify commit counts, no rotation and every key after reopen. The established local build, functional, race and fuzz checks are recorded in the text logs.

After the initial interleaved run, interleave_confirm.sh reuses the same controller and worker binaries with the worker slots exchanged on a fresh volume. Raw controller slot names in interleaved-confirm-wire.jsonl are reversed. make_report.py explicitly maps them back to revision identity. The call-interleaved table pools the per-round comparisons from both campaigns (12 pairs).
