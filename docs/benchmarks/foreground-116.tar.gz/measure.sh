#!/usr/bin/env bash
set -eu -o pipefail
out=$(cd "$(dirname "$0")" && pwd)
candidate=$1; suite=$2; from=${3:-1}; to=${4:-6}
docker run --rm --platform linux/arm64 --cpus 4 --network none --mount type=volume,dst=/data -v "$out/bins:/binout:ro" -v "$out/logs:/logs" -e TARP_BASE="${TARP_BASE:-base}" -e GOMAXPROCS=4 -e TARP_FOREGROUND_TRIAL="$suite" -e TMPDIR=/data/tmp "$(cat "$out/image")" bash -eu -o pipefail -c '
mkdir -p "$TMPDIR"
for ((i=$2;i<=$3;i++));do
 if ((i%2));then order="base trial";else order="trial base";fi
 for side in $order;do
  arm=$TARP_BASE; if [[ $side == trial ]];then arm=$1;fi
  log=/logs/$1-$side-$i.log
  /binout/$arm -test.run "^TestForegroundTrial$" -test.v -test.timeout 10m > "$log" || { tail -40 "$log"; exit 1; }
 done
 echo "$1 pair $i complete"
done' bash "$candidate" "$from" "$to"
