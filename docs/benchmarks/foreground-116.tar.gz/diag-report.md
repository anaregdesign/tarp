# Issue 116 paired default-memory batch write diagnosis

6 paired process runs per revision, 128 measured calls per stratum per run. Base is 6c2c3d2, current is 357e758. Each stratum uses one foreground caller, 16 keys per call, a warm 256-key dataset, and a parked cleaner. The exact active segment occupancy is set by untimed ordinary writes. Every call checks committed sequence advancement and actual rotation. Reopen checks all measured keys. Both revisions use the same instrumented build and fixed Go image.

Run order alternates by pair: old/current then current/old. Size order alternates likewise. Values below are medians of per-run statistics. Delta is the median of within-round percentage differences. Higher/lower/tie counts only compare corresponding raw rounds. Foreground entries/s counts only the 16 records and timed call duration, excluding fixture preparation.

| Target / value | Operation | Rotated | Measure | Old | Current | Paired delta | Higher/lower/tie |
|---|---|---|---|---:|---:|---:|---:|
| 16 KiB / 256 B | BatchPut | no | mean ms | 0.797 | 0.732 | -7.8% | 2/4/0 |
| 16 KiB / 256 B | BatchPut | no | p99 ms | 1.669 | 1.879 | +5.4% | 3/3/0 |
| 16 KiB / 256 B | BatchPut | no | entries/s | 20066 | 21859 | +8.6% | 4/2/0 |
| 16 KiB / 256 B | BatchPut | yes | mean ms | 1.160 | 0.988 | -8.5% | 2/4/0 |
| 16 KiB / 256 B | BatchPut | yes | p99 ms | 1.341 | 1.488 | -5.8% | 3/3/0 |
| 16 KiB / 256 B | BatchPut | yes | entries/s | 13857 | 16196 | +9.7% | 4/2/0 |
| 16 KiB / 256 B | BatchDelete | no | mean ms | 0.785 | 0.687 | -10.5% | 2/4/0 |
| 16 KiB / 256 B | BatchDelete | no | p99 ms | 1.012 | 0.866 | -13.4% | 2/4/0 |
| 16 KiB / 256 B | BatchDelete | no | entries/s | 20432 | 23308 | +12.2% | 4/2/0 |
| 16 KiB / 256 B | BatchDelete | yes | mean ms | 1.019 | 0.948 | -7.7% | 2/4/0 |
| 16 KiB / 256 B | BatchDelete | yes | p99 ms | 2.659 | 1.236 | -55.1% | 1/5/0 |
| 16 KiB / 256 B | BatchDelete | yes | entries/s | 15705 | 16889 | +8.4% | 4/2/0 |
| 4 MiB / 64 KiB | BatchPut | no | mean ms | 1.469 | 1.552 | +3.6% | 4/2/0 |
| 4 MiB / 64 KiB | BatchPut | no | p99 ms | 3.131 | 3.236 | -11.0% | 2/4/0 |
| 4 MiB / 64 KiB | BatchPut | no | entries/s | 10895 | 10309 | -3.4% | 2/4/0 |
| 4 MiB / 64 KiB | BatchPut | yes | mean ms | 1.820 | 1.724 | -5.3% | 2/4/0 |
| 4 MiB / 64 KiB | BatchPut | yes | p99 ms | 3.924 | 3.571 | -17.0% | 2/4/0 |
| 4 MiB / 64 KiB | BatchPut | yes | entries/s | 8792 | 9282 | +5.6% | 4/2/0 |
| 4 MiB / 64 KiB | BatchDelete | no | mean ms | 0.700 | 0.744 | +5.0% | 4/2/0 |
| 4 MiB / 64 KiB | BatchDelete | no | p99 ms | 2.142 | 2.012 | -9.2% | 2/4/0 |
| 4 MiB / 64 KiB | BatchDelete | no | entries/s | 22852 | 21563 | -4.7% | 2/4/0 |
| 4 MiB / 64 KiB | BatchDelete | yes | mean ms | 1.129 | 1.137 | -2.1% | 3/3/0 |
| 4 MiB / 64 KiB | BatchDelete | yes | p99 ms | 4.643 | 3.917 | +4.0% | 3/3/0 |
| 4 MiB / 64 KiB | BatchDelete | yes | entries/s | 14176 | 14069 | +2.3% | 3/3/0 |

## Phase timings

Microseconds per measured call. Index preparation sums all 16 index.stage intervals. Writer wait times the gate-acquisition hook pair. Sync phases time the actual Sync call hooks; a phase marked absent for a path was not invoked. Phase p99s identify variation separately and cannot be added or subtracted from whole-call p99. The instrumentation does not time DATA writes, CURRENT rename, open/close system calls or memory publication separately.

| Target / value | Operation | Rotated | Phase | Statistic | Old µs | Current µs | Paired delta | Higher/lower/tie |
|---|---|---|---|---|---:|---:|---:|---:|
| 16 KiB / 256 B | BatchPut | no | writer_wait | mean | 0.04 | 0.04 | -5.8% | 1/5/0 |
| 16 KiB / 256 B | BatchPut | no | writer_wait | p99 | 0.08 | 0.08 | -0.6% | 1/3/2 |
| 16 KiB / 256 B | BatchPut | no | index_prepare | mean | 3.92 | 3.44 | -9.1% | 2/4/0 |
| 16 KiB / 256 B | BatchPut | no | index_prepare | p99 | 17.21 | 9.90 | -48.8% | 1/5/0 |
| 16 KiB / 256 B | BatchPut | no | data.sync | mean | 324.79 | 290.87 | -11.7% | 2/4/0 |
| 16 KiB / 256 B | BatchPut | no | data.sync | p99 | 557.48 | 523.83 | +22.3% | 3/3/0 |
| 16 KiB / 256 B | BatchPut | no | current.sync | mean | 261.31 | 232.89 | -13.2% | 2/4/0 |
| 16 KiB / 256 B | BatchPut | no | current.sync | p99 | 445.40 | 296.79 | -20.3% | 2/4/0 |
| 16 KiB / 256 B | BatchPut | no | current.dirsync | mean | 176.36 | 161.36 | -6.7% | 2/4/0 |
| 16 KiB / 256 B | BatchPut | no | current.dirsync | p99 | 234.27 | 184.44 | -15.0% | 2/4/0 |
| 16 KiB / 256 B | BatchPut | yes | writer_wait | mean | 0.04 | 0.04 | -0.0% | 3/3/0 |
| 16 KiB / 256 B | BatchPut | yes | writer_wait | p99 | 0.08 | 0.08 | +0.0% | 2/1/3 |
| 16 KiB / 256 B | BatchPut | yes | index_prepare | mean | 4.01 | 3.77 | -5.8% | 1/5/0 |
| 16 KiB / 256 B | BatchPut | yes | index_prepare | p99 | 16.96 | 14.42 | -7.4% | 3/3/0 |
| 16 KiB / 256 B | BatchPut | yes | segment.sync | mean | 293.93 | 293.13 | -2.0% | 2/4/0 |
| 16 KiB / 256 B | BatchPut | yes | segment.sync | p99 | 434.38 | 446.58 | -2.2% | 2/4/0 |
| 16 KiB / 256 B | BatchPut | yes | catalog.sync | mean | 300.19 | 241.26 | -14.6% | 2/4/0 |
| 16 KiB / 256 B | BatchPut | yes | catalog.sync | p99 | 395.15 | 308.79 | -8.3% | 2/4/0 |
| 16 KiB / 256 B | BatchPut | yes | catalog.dirsync | mean | 0.34 | 0.33 | -4.4% | 1/5/0 |
| 16 KiB / 256 B | BatchPut | yes | catalog.dirsync | p99 | 0.44 | 0.42 | -3.8% | 2/3/1 |
| 16 KiB / 256 B | BatchPut | yes | current.sync | mean | 259.94 | 237.69 | -6.2% | 3/3/0 |
| 16 KiB / 256 B | BatchPut | yes | current.sync | p99 | 398.48 | 320.90 | -9.3% | 2/4/0 |
| 16 KiB / 256 B | BatchPut | yes | current.dirsync | mean | 164.09 | 162.36 | +0.1% | 3/3/0 |
| 16 KiB / 256 B | BatchPut | yes | current.dirsync | p99 | 206.06 | 194.15 | -6.6% | 1/5/0 |
| 16 KiB / 256 B | BatchDelete | no | writer_wait | mean | 0.05 | 0.04 | -6.6% | 1/5/0 |
| 16 KiB / 256 B | BatchDelete | no | writer_wait | p99 | 0.08 | 0.08 | -24.7% | 1/3/2 |
| 16 KiB / 256 B | BatchDelete | no | index_prepare | mean | 3.90 | 4.03 | -3.4% | 2/4/0 |
| 16 KiB / 256 B | BatchDelete | no | index_prepare | p99 | 7.56 | 14.71 | +63.9% | 4/2/0 |
| 16 KiB / 256 B | BatchDelete | no | data.sync | mean | 266.33 | 248.69 | -2.6% | 3/3/0 |
| 16 KiB / 256 B | BatchDelete | no | data.sync | p99 | 412.33 | 386.21 | -12.9% | 2/4/0 |
| 16 KiB / 256 B | BatchDelete | no | current.sync | mean | 270.41 | 234.77 | -14.6% | 2/4/0 |
| 16 KiB / 256 B | BatchDelete | no | current.sync | p99 | 393.19 | 318.65 | -19.3% | 1/5/0 |
| 16 KiB / 256 B | BatchDelete | no | current.dirsync | mean | 182.80 | 164.90 | -9.6% | 1/5/0 |
| 16 KiB / 256 B | BatchDelete | no | current.dirsync | p99 | 244.81 | 204.58 | -17.0% | 1/5/0 |
| 16 KiB / 256 B | BatchDelete | yes | writer_wait | mean | 0.04 | 0.04 | -3.6% | 1/5/0 |
| 16 KiB / 256 B | BatchDelete | yes | writer_wait | p99 | 0.08 | 0.08 | +0.0% | 0/1/5 |
| 16 KiB / 256 B | BatchDelete | yes | index_prepare | mean | 4.24 | 3.49 | -3.8% | 3/3/0 |
| 16 KiB / 256 B | BatchDelete | yes | index_prepare | p99 | 15.71 | 12.73 | -2.8% | 3/3/0 |
| 16 KiB / 256 B | BatchDelete | yes | segment.sync | mean | 258.98 | 233.43 | -12.1% | 1/5/0 |
| 16 KiB / 256 B | BatchDelete | yes | segment.sync | p99 | 427.98 | 325.42 | -23.6% | 1/5/0 |
| 16 KiB / 256 B | BatchDelete | yes | catalog.sync | mean | 264.88 | 255.71 | -2.3% | 2/4/0 |
| 16 KiB / 256 B | BatchDelete | yes | catalog.sync | p99 | 383.98 | 348.46 | -11.6% | 3/3/0 |
| 16 KiB / 256 B | BatchDelete | yes | catalog.dirsync | mean | 0.34 | 0.33 | -3.2% | 2/4/0 |
| 16 KiB / 256 B | BatchDelete | yes | catalog.dirsync | p99 | 0.46 | 0.46 | +4.8% | 3/3/0 |
| 16 KiB / 256 B | BatchDelete | yes | current.sync | mean | 246.60 | 228.95 | -5.5% | 1/5/0 |
| 16 KiB / 256 B | BatchDelete | yes | current.sync | p99 | 409.90 | 316.54 | -18.9% | 1/5/0 |
| 16 KiB / 256 B | BatchDelete | yes | current.dirsync | mean | 170.50 | 160.82 | -6.4% | 2/4/0 |
| 16 KiB / 256 B | BatchDelete | yes | current.dirsync | p99 | 229.75 | 243.58 | -1.3% | 3/3/0 |
| 4 MiB / 64 KiB | BatchPut | no | writer_wait | mean | 0.04 | 0.04 | +4.5% | 4/1/1 |
| 4 MiB / 64 KiB | BatchPut | no | writer_wait | p99 | 0.08 | 0.08 | +0.0% | 0/2/4 |
| 4 MiB / 64 KiB | BatchPut | no | index_prepare | mean | 4.39 | 4.22 | -4.0% | 2/4/0 |
| 4 MiB / 64 KiB | BatchPut | no | index_prepare | p99 | 11.73 | 10.56 | -9.4% | 2/4/0 |
| 4 MiB / 64 KiB | BatchPut | no | data.sync | mean | 688.33 | 731.28 | +7.1% | 4/2/0 |
| 4 MiB / 64 KiB | BatchPut | no | data.sync | p99 | 2374.60 | 2344.38 | -11.6% | 2/4/0 |
| 4 MiB / 64 KiB | BatchPut | no | current.sync | mean | 262.47 | 254.81 | -0.1% | 3/3/0 |
| 4 MiB / 64 KiB | BatchPut | no | current.sync | p99 | 434.69 | 373.00 | -7.3% | 1/5/0 |
| 4 MiB / 64 KiB | BatchPut | no | current.dirsync | mean | 172.43 | 169.78 | +1.3% | 4/2/0 |
| 4 MiB / 64 KiB | BatchPut | no | current.dirsync | p99 | 240.00 | 221.83 | +0.4% | 3/3/0 |
| 4 MiB / 64 KiB | BatchPut | yes | writer_wait | mean | 0.06 | 0.07 | -4.7% | 2/4/0 |
| 4 MiB / 64 KiB | BatchPut | yes | writer_wait | p99 | 0.08 | 0.10 | +0.0% | 2/2/2 |
| 4 MiB / 64 KiB | BatchPut | yes | index_prepare | mean | 4.92 | 4.77 | -3.9% | 2/4/0 |
| 4 MiB / 64 KiB | BatchPut | yes | index_prepare | p99 | 16.88 | 15.79 | -24.8% | 2/4/0 |
| 4 MiB / 64 KiB | BatchPut | yes | segment.sync | mean | 620.65 | 588.41 | -3.5% | 1/5/0 |
| 4 MiB / 64 KiB | BatchPut | yes | segment.sync | p99 | 731.85 | 708.75 | -1.6% | 2/4/0 |
| 4 MiB / 64 KiB | BatchPut | yes | catalog.sync | mean | 364.55 | 331.71 | -10.8% | 2/4/0 |
| 4 MiB / 64 KiB | BatchPut | yes | catalog.sync | p99 | 2083.19 | 1702.77 | -6.2% | 2/4/0 |
| 4 MiB / 64 KiB | BatchPut | yes | catalog.dirsync | mean | 0.34 | 0.33 | -2.5% | 2/4/0 |
| 4 MiB / 64 KiB | BatchPut | yes | catalog.dirsync | p99 | 0.48 | 0.42 | -16.6% | 1/4/1 |
| 4 MiB / 64 KiB | BatchPut | yes | current.sync | mean | 238.70 | 238.36 | -0.4% | 3/3/0 |
| 4 MiB / 64 KiB | BatchPut | yes | current.sync | p99 | 343.44 | 351.06 | +2.2% | 4/2/0 |
| 4 MiB / 64 KiB | BatchPut | yes | current.dirsync | mean | 166.88 | 167.89 | +0.4% | 3/3/0 |
| 4 MiB / 64 KiB | BatchPut | yes | current.dirsync | p99 | 228.60 | 209.69 | -7.6% | 2/4/0 |
| 4 MiB / 64 KiB | BatchDelete | no | writer_wait | mean | 0.06 | 0.06 | -6.5% | 2/4/0 |
| 4 MiB / 64 KiB | BatchDelete | no | writer_wait | p99 | 0.08 | 0.08 | +0.0% | 2/0/4 |
| 4 MiB / 64 KiB | BatchDelete | no | index_prepare | mean | 4.39 | 4.15 | -7.0% | 1/5/0 |
| 4 MiB / 64 KiB | BatchDelete | no | index_prepare | p99 | 9.63 | 6.35 | -37.8% | 2/4/0 |
| 4 MiB / 64 KiB | BatchDelete | no | data.sync | mean | 249.56 | 266.77 | +1.3% | 4/2/0 |
| 4 MiB / 64 KiB | BatchDelete | no | data.sync | p99 | 1615.00 | 1519.54 | -13.6% | 2/4/0 |
| 4 MiB / 64 KiB | BatchDelete | no | current.sync | mean | 230.87 | 240.48 | +2.8% | 3/3/0 |
| 4 MiB / 64 KiB | BatchDelete | no | current.sync | p99 | 307.85 | 341.40 | +8.1% | 4/2/0 |
| 4 MiB / 64 KiB | BatchDelete | no | current.dirsync | mean | 163.77 | 168.21 | +2.0% | 3/3/0 |
| 4 MiB / 64 KiB | BatchDelete | no | current.dirsync | p99 | 202.17 | 214.65 | +5.3% | 3/3/0 |
| 4 MiB / 64 KiB | BatchDelete | yes | writer_wait | mean | 0.06 | 0.06 | -19.5% | 2/4/0 |
| 4 MiB / 64 KiB | BatchDelete | yes | writer_wait | p99 | 0.08 | 0.10 | +25.0% | 4/1/1 |
| 4 MiB / 64 KiB | BatchDelete | yes | index_prepare | mean | 4.80 | 4.66 | -3.1% | 2/4/0 |
| 4 MiB / 64 KiB | BatchDelete | yes | index_prepare | p99 | 18.96 | 14.52 | -14.3% | 1/5/0 |
| 4 MiB / 64 KiB | BatchDelete | yes | segment.sync | mean | 369.19 | 390.70 | +2.5% | 4/2/0 |
| 4 MiB / 64 KiB | BatchDelete | yes | segment.sync | p99 | 2531.71 | 3135.54 | +11.0% | 5/1/0 |
| 4 MiB / 64 KiB | BatchDelete | yes | catalog.sync | mean | 261.51 | 257.88 | +0.0% | 3/3/0 |
| 4 MiB / 64 KiB | BatchDelete | yes | catalog.sync | p99 | 403.04 | 364.75 | -8.8% | 3/3/0 |
| 4 MiB / 64 KiB | BatchDelete | yes | catalog.dirsync | mean | 0.34 | 0.34 | -0.5% | 2/3/1 |
| 4 MiB / 64 KiB | BatchDelete | yes | catalog.dirsync | p99 | 0.46 | 0.48 | +4.7% | 4/2/0 |
| 4 MiB / 64 KiB | BatchDelete | yes | current.sync | mean | 236.89 | 255.12 | +8.4% | 4/2/0 |
| 4 MiB / 64 KiB | BatchDelete | yes | current.sync | p99 | 336.96 | 355.19 | +7.2% | 4/2/0 |
| 4 MiB / 64 KiB | BatchDelete | yes | current.dirsync | mean | 163.63 | 169.72 | +4.3% | 4/2/0 |
| 4 MiB / 64 KiB | BatchDelete | yes | current.dirsync | p99 | 200.58 | 208.71 | +2.8% | 3/3/0 |
