#!/usr/bin/env python3
"""Summarize six paired rounds from btree-micro.sh run as CSV."""

import argparse
import csv
import re
import sys
from pathlib import Path
from statistics import median


def read(path):
    lines = path.read_text().splitlines()
    if not lines or lines[-1] != "PASS":
        raise ValueError(f"{path}: incomplete or failed test")
    rows = {}
    for line in lines:
        if not line.startswith("Benchmark"):
            continue
        m = re.fullmatch(r"BenchmarkIssue114Mutate/(overwrite|delete)-4\s+2048\s+([\d.]+) ns/op\s+([\d.]+) B/op\s+([\d.]+) allocs/op\s*", line)
        if not m or m[1] in rows:
            raise ValueError(f"{path}: unexpected row {line}")
        rows[m[1]] = tuple(map(float, m.groups()[1:]))
    if rows.keys() != {"overwrite", "delete"}:
        raise ValueError(f"{path}: incomplete workload set")
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    directory = parser.parse_args().directory
    try:
        arms = {
            side: [read(directory / f"{side}-{r}.log") for r in range(1, 7)]
            for side in ("base", "trial")
        }
        writer = csv.writer(sys.stdout, lineterminator="\n")
        writer.writerow(["workload", "pairs", "base_ns_op", "trial_ns_op", "paired_throughput_pct", "wins", "base_B_op", "trial_B_op", "base_allocs_op", "trial_allocs_op"])
        for name in ("overwrite", "delete"):
            base = [row[name] for row in arms["base"]]
            trial = [row[name] for row in arms["trial"]]
            speed = [100 * (b[0] / t[0] - 1) for b, t in zip(base, trial)]
            writer.writerow([name, len(base), median(b[0] for b in base), median(t[0] for t in trial),
                             round(median(speed), 4), sum(v > 0 for v in speed),
                             median(b[1] for b in base), median(t[1] for t in trial),
                             median(b[2] for b in base), median(t[2] for t in trial)])
    except (ValueError, OSError) as exc:
        parser.exit(1, f"{exc}\n")


if __name__ == "__main__":
    main()
