#!/usr/bin/env bash
set -euo pipefail
out=$(cd "$(dirname "$0")/.." && pwd)
repo=$(git rev-parse --show-toplevel)
scratch=$(mktemp -d)
trap 'rm -rf "$scratch"' EXIT
image=$(cat "$out/image")
for spec in old:6c2c3d2 current:357e758; do
	arm=${spec%:*}
	revision=$(git -C "$repo" rev-parse "${spec#*:}^{commit}")
	mkdir "$scratch/$arm"
	git -C "$repo" archive "$revision" | tar -xf - -C "$scratch/$arm"
	cp "$out/drivers/diag_test.go" "$scratch/$arm/benchmark/issue116_diag_test.go"
	python3 "$out/drivers/diag_instrument.py" "$scratch/$arm"
	docker run --rm --network none --cpus 4 --platform linux/arm64 \
		-v "$scratch/$arm:/src:ro" -v "$out/bins:/bins" -w /src \
		-e 'GOMAXPROCS=4' -e 'GOPROXY=off' -e 'GOTOOLCHAIN=local' -e "output=/bins/diag-$arm" \
		"$image" bash -ec 'go test -buildvcs=false -c -o "$output" ./benchmark'
	printf '%s %s\n' "$arm" "$revision"
done
shasum -a 256 "$out/bins/diag-old" "$out/bins/diag-current" "$out/drivers/diag_test.go" "$out/drivers/diag_instrument.py"
