//go:build linux

package benchmark

import (
	"bytes"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"slices"
	"strings"
	"testing"
	"time"

	"github.com/anaregdesign/tarp"
	"github.com/anaregdesign/tarp/internal/cache"
	"github.com/anaregdesign/tarp/internal/engine"
)

type trialRow struct {
	Name                        string
	N                           int
	Ns, P50, P99, Bytes, Allocs float64
	ReadBytes                   uint64
}

func trialTime(t *testing.T, name string, n int, before func(), call func(int), io *containerBatchIO) {
	t.Helper()
	if before != nil {
		before()
	}
	runtime.GC()
	var start, end runtime.MemStats
	sample := make([]int64, n)
	var first uint64
	if io != nil {
		var err error
		first, err = io.ReadBytes()
		if err != nil {
			t.Fatal(err)
		}
	}
	runtime.ReadMemStats(&start)
	tick := time.Now()
	for i := range n {
		now := time.Now()
		call(i)
		sample[i] = time.Since(now).Nanoseconds()
	}
	elapsed := time.Since(tick)
	runtime.ReadMemStats(&end)
	var disk uint64
	if io != nil {
		last, err := io.ReadBytes()
		if err != nil {
			t.Fatal(err)
		}
		disk = last - first
	}
	slices.Sort(sample)
	row := trialRow{name, n, float64(elapsed.Nanoseconds()) / float64(n), float64(sample[(n-1)/2]), float64(sample[(99*n+99)/100-1]), float64(end.TotalAlloc-start.TotalAlloc) / float64(n), float64(end.Mallocs-start.Mallocs) / float64(n), disk}
	line, err := json.Marshal(row)
	if err != nil {
		t.Fatal(err)
	}
	fmt.Printf("FG116 %s\n", line)
}

func TestForegroundTrial(t *testing.T) {
	suite := os.Getenv("TARP_FOREGROUND_TRIAL")
	if suite == "" {
		t.Skip("opt-in experiment")
	}
	has := func(s string) bool { return slices.Contains(strings.Split(suite, ","), s) }
	if has("mixed") {
		trialMixed(t)
	}
	if has("lru") {
		c := cache.New(1 << 20)
		k := []byte("first")
		v := []byte("value")
		c.Put("first", v)
		c.Put("second", v)
		c.Get(k)
		trialTime(t, "cache/get-mru", 100000, nil, func(int) {
			if _, ok := c.Get(k); !ok {
				t.Fatal("absent")
			}
		}, nil)
		trialTime(t, "cache/overwrite", 100000, nil, func(int) { c.Put("first", v) }, nil)
	}
	for _, m := range []struct {
		mode engine.IndexMode
		name string
	}{{engine.IndexMemory, "memory"}, {engine.IndexBTree, "btree"}} {
		for _, spec := range []struct {
			group, op               string
			size, keys, concurrency int
		}{
			{"largeconfirm", "read", 9216, 1024, 8}, {"largeconfirm", "read", 65536, 1024, 8}, {"writeslong", "write", 64, 8192, 8}, {"large", "read", 65536, 256, 8}, {"large", "read", 512, 256, 8}, {"contiguous", "layout", 64, 512, 8}, {"contiguous", "layout", 64, 512, 1},
			{"lru", "cached", 64, 128, 8}, {"writes", "write", 64, 4096, 8},
		} {
			if !has(spec.group) {
				continue
			}
			t.Run(fmt.Sprintf("%s/%s/%d/%d", m.name, spec.op, spec.size, spec.concurrency), func(t *testing.T) {
				nkeys := spec.keys
				keys, val, opts := measurementInput(spec.size, nkeys)
				opts.IndexMode = m.mode
				opts.BatchGetReadConcurrency = spec.concurrency
				opts.MaxRecordBytes = 128 << 10
				opts.TargetSegmentBytes = 4 << 20
				if spec.op == "read" {
					opts.ValueCacheBudgetBytes = int64(spec.size + 256)
				}
				dbdir := filepath.Join(t.TempDir(), "db")
				core, err := engine.OpenWithHooks(dbdir, opts, nil, &engine.Hooks{CleanerStart: make(chan struct{})})
				if err != nil {
					t.Fatal(err)
				}
				db := (*tarp.DB)(core)
				defer func() {
					if err := db.Close(); err != nil {
						t.Error(err)
					}
				}()
				entries := make([]tarp.Entry, nkeys)
				for i := range keys {
					entries[i] = tarp.Entry{Key: keys[i], Value: val}
				}
				for i := 0; i < nkeys; {
					width := min(nkeys-i, 64)
					if spec.size > 8192 {
						width = min(width, 32)
					}
					if err := db.BatchPut(entries[i : i+width]); err != nil {
						t.Fatal(err)
					}
					i += width
				}
				name := m.name + "/" + spec.op + fmt.Sprintf("/%d/%d/", spec.size, spec.concurrency)
				verify := func(got []byte) {
					if len(got) != len(val) || got[len(got)-1] != val[len(val)-1] {
						t.Fatal("unexpected value")
					}
				}
				get := func(key []byte) {
					b, err := db.Get(key)
					if err != nil {
						t.Fatal(err)
					}
					verify(b)
				}
				batch := func(kk [][]byte) {
					rows, err := db.BatchGet(kk)
					if err != nil || len(rows) != len(kk) {
						t.Fatal(err, len(rows))
					}
					for _, r := range rows {
						if !r.Found {
							t.Fatal("absent")
						}
						verify(r.Value)
					}
				}
				clear := func() { engine.Observe(core).ClearCache() }
				durable := func(err error) {
					if err != nil {
						t.Fatal(err)
					}
				}
				switch spec.op {
				case "cached":
					get(keys[0])
					trialTime(t, name+"get-mru", 100000, nil, func(int) { get(keys[0]) }, nil)
					trialTime(t, name+"get-cycling", 100000, nil, func(i int) { get(keys[i%len(keys)]) }, nil)
					trialTime(t, name+"batchget", 2000, nil, func(i int) { off := i % (nkeys - 32); batch(keys[off : off+32]) }, nil)
				case "read":
					disk, err := openContainerBatchIO(dbdir)
					if err != nil {
						t.Fatal(err)
					}
					defer disk.Close()
					for _, cold := range []bool{false, true} {
						label := "warm"
						n := 1024
						bn := 128
						if spec.group == "largeconfirm" {
							n = 4096
							bn = 512
						}
						if cold {
							label = "advised"
							n = 256
							bn = nkeys / 16
							n = nkeys
						}
						prep := func() {
							clear()
							if cold {
								durable(disk.Evict())
							} else {
								durable(disk.Warm())
							}
						}
						trialTime(t, name+label+"-get", n, prep, func(i int) { get(keys[(i*73)%nkeys]) }, disk)
						trialTime(t, name+label+"-batchget16", bn, prep, func(i int) {
							var kk [16][]byte
							for j := range kk {
								kk[j] = keys[((i*16+j)*73)%nkeys]
							}
							batch(kk[:])
						}, disk)
					}
				case "layout":
					trialTime(t, name+"hot32", 1600, nil, func(i int) { off := i % (nkeys - 32); batch(keys[off : off+32]) }, nil)
					clear()
					trialTime(t, name+"adjacent32", 1600, nil, func(i int) { off := (i * 32) % nkeys; batch(keys[off : off+32]) }, nil)
					trialTime(t, name+"scattered32", 1600, nil, func(i int) {
						var kk [32][]byte
						for j := range kk {
							kk[j] = keys[(i+73*j)%nkeys]
						}
						batch(kk[:])
					}, nil)
				case "write":
					// Each intended update is present. Deletes consume disjoint seeded keys.
					n := 128
					if spec.group == "writeslong" {
						n = 384
					}
					trialTime(t, name+"put", n, nil, func(i int) { durable(db.Put(keys[(i*73)%nkeys], val)) }, nil)
					var scattered [16]tarp.Entry
					trialTime(t, name+"batchput16", n, nil, func(i int) {
						for j := range scattered {
							scattered[j] = entries[((i*16+j)*73)%nkeys]
						}
						durable(db.BatchPut(scattered[:]))
					}, nil)
					trialTime(t, name+"batchput16-adjacent", n, nil, func(i int) { off := 16 * i; durable(db.BatchPut(entries[off : off+16])) }, nil)
					trialTime(t, name+"put-new", n, nil, func(i int) { k := bytes.Clone(keys[i]); k[0] = 'x'; durable(db.Put(k, val)) }, nil)
					trialTime(t, name+"delete", n, nil, func(i int) { durable(db.Delete(keys[i])) }, nil)
					trialTime(t, name+"batchdelete16", n, nil, func(i int) { off := n + i*16; durable(db.BatchDelete(keys[off : off+16])) }, nil)
				}
			})
		}
	}
}

// Mixed runs keep the disk access cold on each call. Fadvise and fixture
// validation are outside the measured API time.
func trialMixed(t *testing.T) {
	for _, mode := range []engine.IndexMode{engine.IndexMemory, engine.IndexBTree} {
		const count = 8192
		keys, val, opts := measurementInput(64, count)
		opts.IndexMode = mode
		opts.TargetSegmentBytes = 4 << 20
		dir := filepath.Join(t.TempDir(), "db")
		core, err := engine.OpenWithHooks(dir, opts, nil, &engine.Hooks{CleanerStart: make(chan struct{})})
		if err != nil {
			t.Fatal(err)
		}
		db := (*tarp.DB)(core)
		for start := 0; start < count; start += 128 {
			var entries [128]tarp.Entry
			for j := range entries {
				entries[j] = tarp.Entry{Key: keys[start+j], Value: val}
			}
			if err := db.BatchPut(entries[:]); err != nil {
				t.Fatal(err)
			}
		}
		engine.Observe(core).ClearCache()
		control, err := openContainerBatchIO(dir)
		if err != nil {
			t.Fatal(err)
		}
		for _, layout := range []string{"adjacent256", "gapped-8x4", "scattered32"} {
			for _, cold := range []bool{false, true} {
				const n = 128
				var duration [n]int64
				first, err := control.ReadBytes()
				if err != nil {
					t.Fatal(err)
				}
				var total int64
				runtime.GC()
				var ms0, ms1 runtime.MemStats
				runtime.ReadMemStats(&ms0)
				for i := range n {
					var kk [256][]byte
					length := 32
					switch layout {
					case "adjacent256":
						length = 256
						for j := range length {
							kk[j] = keys[(i*37%(count-length))+j]
						}
					case "gapped-8x4":
						for j := range length {
							kk[j] = keys[((i*37+j/4*997)%(count-4))+j%4]
						}
					case "scattered32":
						for j := range length {
							kk[j] = keys[(i*37+j*197)%count]
						}
					}
					if cold {
						if err := control.Evict(); err != nil {
							t.Fatal(err)
						}
					}
					start := time.Now()
					rows, err := db.BatchGet(kk[:length])
					duration[i] = time.Since(start).Nanoseconds()
					total += duration[i]
					if err != nil || len(rows) != length {
						t.Fatal(err, len(rows))
					}
					for _, r := range rows {
						if !r.Found || !bytes.Equal(r.Value, val) {
							t.Fatal("wrong value")
						}
					}
				}
				runtime.ReadMemStats(&ms1)
				last, err := control.ReadBytes()
				if err != nil {
					t.Fatal(err)
				}
				slices.Sort(duration[:])
				modeName := "memory"
				if mode == engine.IndexBTree {
					modeName = "btree"
				}
				name := fmt.Sprintf("%s/mixed/%s/evict-%t", modeName, layout, cold)
				row := trialRow{name, n, float64(total) / n, float64(duration[63]), float64(duration[126]), float64(ms1.TotalAlloc-ms0.TotalAlloc) / n, float64(ms1.Mallocs-ms0.Mallocs) / n, last - first}
				b, err := json.Marshal(row)
				if err != nil {
					t.Fatal(err)
				}
				fmt.Printf("FG116 %s\n", b)
			}
		}
		if err := control.Close(); err != nil {
			t.Fatal(err)
		}
		if err := db.Close(); err != nil {
			t.Fatal(err)
		}
	}
}
