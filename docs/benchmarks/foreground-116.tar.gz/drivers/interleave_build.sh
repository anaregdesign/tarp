#!/usr/bin/env bash
set -euo pipefail
out=$(cd "$(dirname "$0")/.." && pwd)
export TARP_DRIVER="$out/drivers/interleave_worker_test.go"
bash "$out/build.sh" iw-base
bash "$out/build.sh" iw-final merged
docker run --rm --network none --platform linux/arm64 --cpus 4 -e GOMAXPROCS=4 -e GOTOOLCHAIN=local -e GOPROXY=off --mount type=volume,src=tarp-116-buildcache,dst=/root/.cache/go-build -v "$out/drivers:/src:ro" -v "$out/bins:/bins" -w /src "$(cat "$out/image")" go build -trimpath -buildvcs=false -o /bins/iw-control interleave_controller.go
