"""Add the closing index.prepare timing point to a disposable benchmark checkout."""
from pathlib import Path
import sys

p = Path(sys.argv[1]) / "internal/engine/index.go"
s = p.read_text()
anchor = 'if err := db.store.IO.Check("index.prepare:before"); err != nil {\n\t\treturn storage.Location{}, err\n\t}'
addition = '\n\tdefer db.store.IO.Check("diag.index.prepare:after")'
if s.count(anchor) != 1:
    sys.exit(f"Unexpected staging hook in {p}")
if addition not in s:
    p.write_text(s.replace(anchor, anchor + addition))
