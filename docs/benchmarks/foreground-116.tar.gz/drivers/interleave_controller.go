// An external measurement harness for the two persistent issue 116 test workers.
package main

import (
	"encoding/binary"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"os/exec"
	"strconv"
)

const samples = 384

var arms = [...]string{"base", "final"}
var ops = [...]string{"put", "batchput16", "delete", "batchdelete16"}

type worker struct {
	cmd    *exec.Cmd
	input  io.WriteCloser
	output *os.File
}

func (w *worker) read() uint64 {
	var sample [8]byte
	_, err := io.ReadFull(w.output, sample[:])
	if err != nil {
		panic(fmt.Sprintf("worker %s: %v", w.cmd.Path, err))
	}
	return binary.LittleEndian.Uint64(sample[:])
}

func start(arm, mode string) *worker {
	r, w, err := os.Pipe()
	if err != nil {
		panic(err)
	}
	cmd := exec.Command("/bins/iw-"+arm, "-test.run=^TestIssue116InterleavedWorker$", "-test.timeout=10m")
	cmd.Env = append(os.Environ(), "TARP116_WORKER_MODE="+mode, "TARP116_CALLS="+strconv.Itoa(samples))
	cmd.Stdout, cmd.Stderr = os.Stderr, os.Stderr
	cmd.ExtraFiles = []*os.File{w}
	input, err := cmd.StdinPipe()
	if err != nil {
		panic(err)
	}
	if err = cmd.Start(); err != nil {
		panic(err)
	}
	if err = w.Close(); err != nil {
		panic(err)
	}
	worker := &worker{cmd: cmd, input: input, output: r}
	if worker.read() != 1 {
		panic("worker did not confirm seed")
	}
	return worker
}

func (w *worker) request(op int) uint64 {
	b := [1]byte{byte(op)}
	if m, err := w.input.Write(b[:]); m != 1 || err != nil {
		panic(fmt.Sprintf("worker input: %d %v", m, err))
	}
	return w.read()
}

func (w *worker) finish() {
	if w.request(len(ops)) != 1 {
		panic("worker did not verify recovered state")
	}
	if err := w.input.Close(); err != nil {
		panic(err)
	}
	if err := w.cmd.Wait(); err != nil {
		panic(err)
	}
	if err := w.output.Close(); err != nil {
		panic(err)
	}
}

type record struct {
	Round     int      `json:"round"`
	Mode      string   `json:"mode"`
	Operation string   `json:"operation"`
	First     string   `json:"first_in_pair_zero"`
	Base      []uint64 `json:"base_ns"`
	Final     []uint64 `json:"final_ns"`
}

func run(round int, mode string, out *json.Encoder) {
	var workers [2]*worker
	order := (round - 1) % 2
	for j := range 2 {
		a := (order + j) % 2
		workers[a] = start(arms[a], mode)
	}
	var rows [len(ops)]record
	for op, name := range ops {
		first := (order + op) % 2
		durations := [2][]uint64{make([]uint64, samples), make([]uint64, samples)}
		for i := range samples {
			for j := range 2 {
				a := (first + i + j) % 2
				ns := workers[a].request(op)
				if ns == 0 {
					panic("invalid public timing")
				}
				durations[a][i] = ns
			}
		}
		rows[op] = record{round, mode, name, arms[first], durations[0], durations[1]}
	}
	for j := range 2 {
		workers[(order+j)%2].finish()
	}
	// Write one raw array per arm only after both independent databases
	// passed closed-file recovery. No logging or disk writes by the controller
	// can share the write slot with a measured call.
	for _, r := range rows {
		if err := out.Encode(r); err != nil {
			panic(err)
		}
	}
	fmt.Fprintf(os.Stderr, "completed and verified round %d %s\n", round, mode)
}
func main() {
	out := json.NewEncoder(os.Stdout)
	for round := 1; round <= 6; round++ {
		modes := [2]string{"memory", "btree"}
		if round%2 == 0 {
			modes[0], modes[1] = modes[1], modes[0]
		}
		for _, mode := range modes {
			run(round, mode, out)
		}
	}
}
