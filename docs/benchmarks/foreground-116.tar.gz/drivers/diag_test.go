package benchmark

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"slices"
	"strconv"
	"strings"
	"testing"
	"time"

	"github.com/anaregdesign/tarp/internal/engine"
	"github.com/anaregdesign/tarp/internal/format"
	"github.com/anaregdesign/tarp/internal/storage"
)

// One foreground caller, parked cleaner, no disk tracing. All hooks and timing
// samples below run on that caller. Unmeasured writes select the exact active
// segment occupancy before every measured call.
func TestIssue116Batch16Diagnosis(t *testing.T) {
	if os.Getenv("TARP116_DIAG") == "" {
		t.Skip("opt-in batch write diagnosis")
	}
	samples := 128
	if s := os.Getenv("TARP116_DIAG_N"); s != "" {
		n, err := strconv.Atoi(s)
		if err != nil || n < 1 || n > 4096 {
			t.Fatal("TARP116_DIAG_N must be 1..4096")
		}
		samples = n
	}
	for _, op := range []string{"BatchPut", "BatchDelete"} {
		for _, rotate := range []bool{false, true} {
			t.Run(fmt.Sprintf("%s/rotate=%v", op, rotate), func(t *testing.T) {
				diagnoseBatch16(t, op, rotate, samples)
			})
		}
	}
}

type issue116Sample struct {
	times  [9]int64
	starts [9]time.Time
	counts [9]int
}

var issue116Phases = [...]string{
	"total", "writer_wait", "index_prepare", "data.sync", "segment.sync",
	"catalog.sync", "catalog.dirsync", "current.sync", "current.dirsync",
}

func (s *issue116Sample) mark(i int, end bool) {
	now := time.Now()
	if !end {
		s.starts[i] = now
		return
	}
	s.times[i] += now.Sub(s.starts[i]).Nanoseconds()
	s.counts[i]++
}

func diagnoseBatch16(t *testing.T, op string, rotate bool, samples int) {
	const batchSize = 16
	target, valueSize := 16<<10, 256
	if os.Getenv("TARP116_DIAG_DEFAULT") != "" {
		target, valueSize = 4<<20, 64<<10
	}
	keys, value, opts := measurementInput(valueSize, 256)
	opts.TargetSegmentBytes = int64(target)
	opts.MaxRecordBytes = int64(valueSize + 8192)
	allKeys := keys
	keys = keys[:batchSize]
	// Declared as a local pointer so setup commits take only the nil hook branch.
	var sample *issue116Sample
	fs := &storage.IO{Hook: func(point string) error {
		if sample == nil {
			return nil
		}
		switch point {
		case "index.prepare:before":
			sample.mark(2, false)
		case "diag.index.prepare:after":
			sample.mark(2, true)
		default:
			name, edge, ok := strings.Cut(point, ":")
			if i := slices.Index(issue116Phases[3:], name); ok && i >= 0 {
				sample.mark(3+i, edge == "after")
			}
		}
		return nil
	}}
	hooks := &engine.Hooks{CleanerStart: make(chan struct{}), WriterWait: func(acquired bool) {
		if sample != nil {
			sample.mark(1, acquired)
		}
	}}
	dir := filepath.Join(t.TempDir(), "db")
	db, err := engine.OpenWithHooks(dir, opts, fs, hooks)
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	checked := func(err error) {
		t.Helper()
		if err != nil {
			t.Fatal(err)
		}
	}
	seed := make([]engine.Entry, batchSize)
	updates := make([]engine.Entry, batchSize)
	for i, k := range keys {
		seed[i] = engine.Entry{Key: k, Value: value}
		updates[i] = engine.Entry{Key: k, Value: bytes.Clone(value)}
		updates[i].Value[0] ^= byte(i + 1)
	}
	// Start with the same 256 live keys and 16-entry warmup batches as #115.
	for i := 0; i < len(allKeys); i += batchSize {
		warm := make([]engine.Entry, batchSize)
		for j := range warm {
			warm[j] = engine.Entry{Key: allKeys[i+j], Value: value}
		}
		checked(db.BatchPut(warm))
	}
	// A single unmeasured batch of ordinary records fits exactly and stays
	// within the same per-record maximum used in the #115 campaign.
	fillKey := []byte("fill")
	const fillCount = 64
	fillSize := (target - format.SegmentHeaderBytes) / fillCount
	if fillSize*fillCount != target-format.SegmentHeaderBytes {
		t.Fatal("fixture target is not exactly divisible")
	}
	fillValue := make([]byte, fillSize-format.RecordHeaderBytes-len(fillKey))
	fill := make([]engine.Entry, fillCount)
	for i := range fill {
		fill[i] = engine.Entry{Key: fillKey, Value: fillValue}
	}
	rows := make([]issue116Sample, samples)
	for i := range rows {
		if op == "BatchDelete" {
			checked(db.BatchPut(seed))
		}
		// This batch fills a segment exactly. The optional fence rotates first
		// and gives the measured batch a nearly empty log to append to instead.
		checked(db.BatchPut(fill))
		if !rotate {
			checked(db.Put([]byte("fence"), nil))
		}
		f0 := engine.Observe(db).Frontier()
		sample = &rows[i]
		sample.mark(0, false)
		if op == "BatchPut" {
			err = db.BatchPut(updates)
		} else {
			err = db.BatchDelete(keys)
		}
		sample.mark(0, true)
		sample = nil
		checked(err)
		f1 := engine.Observe(db).Frontier()
		if (f1.ActiveID != f0.ActiveID) != rotate || f1.Sequence-f0.Sequence != batchSize {
			t.Fatalf("wrong rotation/sequence: before %+v, after %+v", f0, f1)
		}
		want := [9]int{1, 1, batchSize, 1, 0, 0, 0, 1, 1}
		if rotate {
			want[3], want[4], want[5], want[6] = 0, 1, 1, 1
		}
		if rows[i].counts != want {
			t.Fatalf("phase event counts %v, want %v (apply diag_instrument.py to both arms)", rows[i].counts, want)
		}
	}
	checked(db.Close())
	image, err := engine.OpenWithHooks(dir, opts, nil, &engine.Hooks{CleanerStart: make(chan struct{})})
	checked(err)
	defer image.Close()
	for i, key := range keys {
		value, err := image.Get(key)
		if op == "BatchPut" && (err != nil || !bytes.Equal(value, updates[i].Value)) || op == "BatchDelete" && !errors.Is(err, engine.ErrNotFound) {
			t.Fatalf("reopen key %x: %x, %v", key, value, err)
		}
	}
	row := map[string]any{"op": op, "rotate": rotate, "n": samples, "target_segment_bytes": target, "value_bytes": len(value), "index": "Memory"}
	for i, phase := range issue116Phases {
		if rows[0].counts[i] == 0 {
			continue
		}
		ns := make([]int64, samples)
		var sum int64
		for j := range rows {
			ns[j] = rows[j].times[i]
			sum += ns[j]
		}
		slices.Sort(ns)
		row[phase] = map[string]any{"mean_ns": sum / int64(samples), "p50_ns": ns[(samples-1)/2], "p99_ns": ns[(99*samples+99)/100-1], "sum_ns": sum}
	}
	b, err := json.Marshal(row)
	checked(err)
	fmt.Printf("TARP116_DIAG %s\n", b)
}
