"""Summarize completed paired diagnosis runs; require both arms in each round."""
from pathlib import Path
from statistics import median
from argparse import ArgumentParser
import json

out = Path(__file__).resolve().parents[1]
p = ArgumentParser()
p.add_argument('--rounds', type=int, default=6)
p.add_argument('--output', type=Path, default=out/'diag-report.md')
args = p.parse_args()
if not 1 <= args.rounds <= 6:
    p.error('--rounds must be 1..6')

runs = {}
for arm in ('old', 'current'):
    for number in range(1, args.rounds + 1):
        path = out/'logs'/f'diag-{arm}-{number}.log'
        rows = [json.loads(line.split(' ', 1)[1]) for line in path.read_text().splitlines() if line.startswith('TARP116_DIAG ')]
        data = {(r['target_segment_bytes'],r['op'],r['rotate']):r for r in rows}
        assert len(data)==len(rows)==8, path
        runs[arm, number] = data

def pair_stats(key, get):
    pairs = [(get(runs['old',i][key]),get(runs['current',i][key])) for i in range(1,args.rounds+1)]
    old, new = zip(*pairs)
    pct = median((c/b-1)*100 for b,c in pairs)
    return median(old),median(new),pct,sum(c>b for b,c in pairs),sum(c<b for b,c in pairs)

def stats_table(key, get, scale, fmt):
    old, cur, delta, higher, lower = pair_stats(key, get)
    return f'{old/scale:{fmt}} | {cur/scale:{fmt}} | {delta:+.1f}% | {higher}/{lower}/{args.rounds-higher-lower}'

def label(key):
    t, op, rotation = key
    return f'{"4 MiB / 64 KiB" if t==4<<20 else "16 KiB / 256 B"} | {op} | {"yes" if rotation else "no"}'

keys = sorted(runs['old',1],key=lambda k: (k[0],k[1] != "BatchPut",k[2]))
assert all(set(table)==set(keys) for table in runs.values())
ns = {r['n'] for table in runs.values() for r in table.values()}
assert len(ns)==1
lines = [
    '# Issue 116 paired default-memory batch write diagnosis','',
    f'{args.rounds} paired process runs per revision, {ns.pop()} measured calls per stratum per run. Base is 6c2c3d2, current is 357e758. Each stratum uses one foreground caller, 16 keys per call, a warm 256-key dataset, and a parked cleaner. The exact active segment occupancy is set by untimed ordinary writes. Every call checks committed sequence advancement and actual rotation. Reopen checks all measured keys. Both revisions use the same instrumented build and fixed Go image.','',
    'Run order alternates by pair: old/current then current/old. Size order alternates likewise. Values below are medians of per-run statistics. Delta is the median of within-round percentage differences. Higher/lower/tie counts only compare corresponding raw rounds. Foreground entries/s counts only the 16 records and timed call duration, excluding fixture preparation.','',
    '| Target / value | Operation | Rotated | Measure | Old | Current | Paired delta | Higher/lower/tie |',
    '|---|---|---|---|---:|---:|---:|---:|',
]
for key in keys:
    for name, get, scale in [
        ('mean ms', lambda r:r['total']['mean_ns'],1e6),
        ('p99 ms', lambda r:r['total']['p99_ns'],1e6),
        ('entries/s',lambda r:r['n']*16*1e9/r['total']['sum_ns'],1),
    ]:
        lines.append(f'| {label(key)} | {name} | {stats_table(key,get,scale,".3f" if scale>1 else ".0f")} |')
lines += ['','## Phase timings','','Microseconds per measured call. Index preparation sums all 16 index.stage intervals. Writer wait times the gate-acquisition hook pair. Sync phases time the actual Sync call hooks; a phase marked absent for a path was not invoked. Phase p99s identify variation separately and cannot be added or subtracted from whole-call p99. The instrumentation does not time DATA writes, CURRENT rename, open/close system calls or memory publication separately.','',
          '| Target / value | Operation | Rotated | Phase | Statistic | Old µs | Current µs | Paired delta | Higher/lower/tie |',
          '|---|---|---|---|---|---:|---:|---:|---:|']
for key in keys:
    for phase in ('writer_wait','index_prepare','data.sync','segment.sync','catalog.sync','catalog.dirsync','current.sync','current.dirsync'):
        if phase not in runs['old',1][key]:
            continue
        for stat in ('mean_ns','p99_ns'):
            lines.append(f'| {label(key)} | {phase} | {stat[:-3]} | {stats_table(key,lambda r:r[phase][stat],1000,".2f")} |')
args.output.write_text('\n'.join(lines)+'\n')
print(args.output)
