#!/usr/bin/env bash
set -euo pipefail
out=$(cd "$(dirname "$0")/.." && pwd)
image=$(cat "$out/image")
start=${1:-1}
end=${2:-6}
n=${TARP116_DIAG_N:-128}
[[ "$start" =~ ^[1-6]$ && "$end" =~ ^[1-6]$ && "$start" -le "$end" ]]
docker run --rm --network none --cpus 4 --platform linux/arm64 \
	-v "$out/bins:/bins:ro" -v "$out/logs:/logs" --mount type=volume,dst=/data \
	-e GOMAXPROCS=4 -e "TARP116_DIAG_N=$n" -e 'TARP116_DIAG=1' -e "start=$start" -e "end=$end" "$image" bash -ec '
	export TMPDIR=/data/tmp
	mkdir -p "$TMPDIR"
	for ((r=start; r<=end; r++)); do
		if ((r % 2)); then arms="old current"; sizes="small default"; else arms="current old"; sizes="default small"; fi
		for arm in $arms; do
			log="/logs/diag-$arm-$r.log"
			if [[ -e "$log" ]]; then
				echo "Refusing to overwrite completed $log; choose only pending rounds." >&2
				exit 1
			fi
			echo "running diagnosis round $r $arm, size order $sizes"
			: > "$log.part"
			for size in $sizes; do
				unset TARP116_DIAG_DEFAULT
				if [[ "$size" == default ]]; then export TARP116_DIAG_DEFAULT=1; fi
				"/bins/diag-$arm" -test.v -test.run "^TestIssue116Batch16Diagnosis$" -test.timeout=4m >> "$log.part" 2>&1 || { tail -12 "$log.part" >&2; exit 1; }
			done
			[[ $(grep -c "^TARP116_DIAG " "$log.part") -eq 8 ]]
			mv "$log.part" "$log"
		done
	done'
