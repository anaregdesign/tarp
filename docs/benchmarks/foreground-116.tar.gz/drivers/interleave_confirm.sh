#!/usr/bin/env bash
set -euo pipefail
out=$(cd "$(dirname "$0")/.." && pwd)
[[ -s "$out/interleaved-writes.jsonl" && ! -e "$out/interleaved-confirm-wire.jsonl" ]]
docker run --rm --network none --platform linux/arm64 --cpus 4 \
	-e GOMAXPROCS=4 -v "$out/bins/iw-final:/bins/iw-base:ro" \
	-v "$out/bins/iw-base:/bins/iw-final:ro" -v "$out/bins/iw-control:/bins/iw-control:ro" \
	--mount type=volume,dst=/data "$(cat "$out/image")" bash -ec '
		export TMPDIR=/data/tmp
		mkdir -p "$TMPDIR"
		findmnt -T /data -n -o SOURCE,FSTYPE,OPTIONS >&2
		sha256sum /bins/iw-base /bins/iw-final /bins/iw-control >&2
		/bins/iw-control
	' > "$out/logs/interleaved-confirm-wire.part" 2> "$out/logs/interleaved-confirm.log"
[[ $(wc -l < "$out/logs/interleaved-confirm-wire.part") -eq 48 ]]
mv "$out/logs/interleaved-confirm-wire.part" "$out/interleaved-confirm-wire.jsonl"
