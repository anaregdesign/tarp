"""Summarize same-call timings, treating each process pair as one round."""
import json, csv
from math import ceil
from pathlib import Path
from statistics import mean,median

out=Path(__file__).resolve().parents[1]
rows = [json.loads(l) for l in (out/'interleaved-writes.jsonl').read_text().splitlines() if l]
assert len(rows)==48
fields=[]
for mode in ('memory','btree'):
    for op in ('put','batchput16','delete','batchdelete16'):
        data=sorted((r for r in rows if (r['mode'],r['operation'])==(mode,op)),key=lambda r:r['round'])
        assert [r['round'] for r in data]==list(range(1,7))
        assert len(set(r['first_in_pair_zero'] for r in data))==2
        stats={}
        for arm in ('base','final'):
            v=[r[arm+'_ns'] for r in data]
            assert all(len(s)==384 and min(s)>0 for s in v)
            stats[arm]={'mean':[mean(s) for s in v],'p50':[median(s) for s in v],'p99':[sorted(s)[ceil(.99*len(s))-1] for s in v]}
        row={'mode':mode,'operation':op,'samples_per_arm':384*6}
        for m in ('mean','p50','p99'):
            b,c=stats['base'][m],stats['final'][m]
            row['base_'+m+'_us']=round(median(b)/1000,2)
            row['final_'+m+'_us']=round(median(c)/1000,2)
            if m=='mean':
                row['paired_throughput_change_pct']=round(median((x/y-1)*100 for x,y in zip(b,c)),2)
                row['throughput_wins']=sum(y<x for x,y in zip(b,c))
            else:
                row['paired_'+m+'_change_pct']=round(median((y/x-1)*100 for x,y in zip(b,c)),2)
                row[m+'_wins']=sum(y<x for x,y in zip(b,c))
        row['call_pair_final_faster']=sum(y<x for r in data for x,y in zip(r['base_ns'],r['final_ns']))
        fields.append(row)
with (out/'interleaved-writes.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields[0].keys());w.writeheader();w.writerows(fields)
lines=[
'# Foreground writes, interleaved after every call','',
'Linux arm64, 4 CPUs, one anonymous ext4 volume in the campaign image. Each of six rounds starts separate baseline and final worker processes with independently initialized DBs, 8,192 identical 16-byte keys and 64-byte values, a 4 MiB segment target and a parked cleaner. The caller updates existing keys for Put and BatchPut, then deletes disjoint existing keys. Each case issues 384 calls per arm; every Batch call has 16 records. In each cell baseline and final run consecutively with the same input and never overlap. Which arm goes first flips on every pair of calls and across rounds. Mode and seed order also alternate by round. Times enclose only the public call inside each process, excluding fixture construction, request/reply IPC, verification, and startup. No per-phase timing hooks were added. Each worker checks 1,536 observed commits, 13,056 records, 1,664 surviving keys and unchanged active segment ID. It then closes, reopens and checks all 8,192 key states before the raw samples for this DB pair are accepted.','',
'P50 and p99 in µs are medians of the six per-round statistics. Relative changes use the median within-round ratio (throughput baseline mean / final mean; timing final / baseline). Wins count rounds out of six. Independent rounds are the replication unit; the 384 calls in a round share a filesystem and worker.','',
'| Index | Operation | Throughput change | Wins | p50 µs base → final | p99 µs base → final | p99 change | p99 wins |',
'|---|---|---:|---:|---:|---:|---:|---:|']
for r in fields:
    lines.append('| {mode} | {operation} | {paired_throughput_change_pct:+.1f}% | {throughput_wins}/6 | {base_p50_us:.1f} → {final_p50_us:.1f} | {base_p99_us:.1f} → {final_p99_us:.1f} | {paired_p99_change_pct:+.1f}% | {p99_wins}/6 |'.format(**r))
(out/'interleaved-writes.md').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines[6:]))
