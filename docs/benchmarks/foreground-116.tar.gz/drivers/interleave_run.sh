#!/usr/bin/env bash
set -euo pipefail
out=$(cd "$(dirname "$0")/.." && pwd)
[[ -e "$out/modules.txt" ]] || { echo 'Waiting for local validation to finish' >&2; exit 1; }
[[ ! -e "$out/interleaved-writes.jsonl" ]] || { echo 'Completed raw data already exists' >&2; exit 1; }
docker run --rm --network none --platform linux/arm64 --cpus 4 \
	-e GOMAXPROCS=4 -v "$out/bins:/bins:ro" --mount type=volume,dst=/data \
	"$(cat "$out/image")" bash -ec 'export TMPDIR=/data/tmp; mkdir -p "$TMPDIR"; findmnt -T /data -n -o SOURCE,FSTYPE,OPTIONS >&2; /bins/iw-control' \
	> "$out/logs/interleaved-writes.part" 2> "$out/logs/interleaved-writes.log"
[[ $(wc -l < "$out/logs/interleaved-writes.part") -eq 48 ]]
mv "$out/logs/interleaved-writes.part" "$out/interleaved-writes.jsonl"
