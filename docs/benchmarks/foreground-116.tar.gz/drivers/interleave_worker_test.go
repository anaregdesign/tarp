//go:build linux

package benchmark

import (
	"bytes"
	"encoding/binary"
	"errors"
	"io"
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"testing"
	"time"

	"github.com/anaregdesign/tarp"
	"github.com/anaregdesign/tarp/internal/engine"
)

// The controller sends a single opcode on stdin and blocks for the response on
// fd 3. No other worker receives a command until the public call has returned.
func TestIssue116InterleavedWorker(t *testing.T) {
	mode := os.Getenv("TARP116_WORKER_MODE")
	if mode == "" {
		t.Skip("requires the paired writes controller")
	}
	n, err := strconv.Atoi(os.Getenv("TARP116_CALLS"))
	if err != nil || n < 256 || n > 480 {
		t.Fatal("expected 256..480 calls per operation")
	}
	const nkeys = 8192
	keys, initial, opts := measurementInput(64, nkeys)
	value := bytes.Clone(initial)
	value[0] ^= 0x55
	switch mode {
	case "memory":
		opts.IndexMode = engine.IndexMemory
	case "btree":
		opts.IndexMode = engine.IndexBTree
	default:
		t.Fatal("invalid mode", mode)
	}
	opts.TargetSegmentBytes = 4 << 20
	opts.MaxRecordBytes = 128 << 10
	parked := &engine.Hooks{CleanerStart: make(chan struct{})}
	dir := filepath.Join(t.TempDir(), "db")
	core, err := engine.OpenWithHooks(dir, opts, nil, parked)
	if err != nil {
		t.Fatal(err)
	}
	db := (*tarp.DB)(core)
	defer db.Close()
	entries := make([]tarp.Entry, nkeys)
	for i, key := range keys {
		entries[i] = tarp.Entry{Key: key, Value: initial}
	}
	for i := 0; i < nkeys; i += 64 {
		if err := db.BatchPut(entries[i : i+64]); err != nil {
			t.Fatal(err)
		}
	}
	before, frontier := db.Stats(), engine.Observe(core).Frontier()
	expected := make([]byte, nkeys) // zero = original, one = overwritten, two = deleted
	replies := os.NewFile(3, "controller")
	defer replies.Close()
	var wire [8]byte
	reply := func(v uint64) {
		binary.LittleEndian.PutUint64(wire[:], v)
		if m, err := replies.Write(wire[:]); err != nil || m != len(wire) {
			t.Fatalf("controller write: %d %v", m, err)
		}
	}
	var counts [4]int
	var batch [16]tarp.Entry
	runtime.GC()
	reply(1)
	for {
		var command [1]byte
		if _, err := io.ReadFull(os.Stdin, command[:]); err != nil {
			t.Fatal(err)
		}
		op := int(command[0])
		if op == 4 {
			break
		}
		if op >= len(counts) || counts[op] >= n {
			t.Fatalf("invalid command %d, counts %v", op, counts)
		}
		i := counts[op]
		counts[op]++
		var start time.Time
		switch op {
		case 0:
			j := (i * 73) % nkeys
			key := keys[j]
			expected[j] = 1
			start = time.Now()
			err = db.Put(key, value)
		case 1:
			for j := range batch {
				k := ((i*16 + j) * 73) % nkeys
				batch[j] = tarp.Entry{Key: keys[k], Value: value}
				expected[k] = 1
			}
			start = time.Now()
			err = db.BatchPut(batch[:])
		case 2:
			key := keys[i]
			expected[i] = 2
			start = time.Now()
			err = db.Delete(key)
		case 3:
			off := n + i*16
			span := keys[off : off+16]
			for j := range 16 {
				expected[off+j] = 2
			}
			start = time.Now()
			err = db.BatchDelete(span)
		}
		ns := time.Since(start).Nanoseconds()
		if err != nil || ns <= 0 {
			t.Fatalf("op %d index %d: duration %d, error %v", op, i, ns, err)
		}
		reply(uint64(ns))
	}
	after, end := db.Stats(), engine.Observe(core).Frontier()
	if counts != [4]int{n, n, n, n} || after.WriteCommits-before.WriteCommits != uint64(4*n) ||
		after.WrittenRecords-before.WrittenRecords != uint64(34*n) || end.Sequence-frontier.Sequence != uint64(34*n) ||
		after.LiveKeys != uint64(nkeys-17*n) || end.ActiveID != frontier.ActiveID {
		t.Fatalf("bad state: calls %v, before %+v, after %+v, frontier %+v -> %+v", counts, before, after, frontier, end)
	}
	if err := db.Close(); err != nil {
		t.Fatal(err)
	}
	image, err := engine.OpenWithHooks(dir, opts, nil, parked)
	if err != nil {
		t.Fatal(err)
	}
	defer image.Close()
	if got := image.Stats().LiveKeys; got != uint64(nkeys-17*n) {
		t.Fatalf("reopened count %d", got)
	}
	for i, k := range keys {
		v, err := image.Get(k)
		switch expected[i] {
		case 2:
			if !errors.Is(err, engine.ErrNotFound) {
				t.Fatalf("deleted key %d: %v", i, err)
			}
		default:
			want := initial
			if expected[i] == 1 {
				want = value
			}
			if err != nil || !bytes.Equal(v, want) {
				t.Fatalf("key %d: %x, %v", i, v, err)
			}
		}
	}
	reply(1)
}
