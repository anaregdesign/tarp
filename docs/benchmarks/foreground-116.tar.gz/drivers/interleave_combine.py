"""Authenticate slot inversion and normalize both six-round paired write campaigns."""
import csv
import json
from math import ceil
from pathlib import Path
from statistics import mean, median

p = Path(__file__).resolve().parents[1]
def saved_hashes(lines):
    return {Path(parts[1]).name:parts[0] for line in lines if len(parts:=line.split())==2 and len(parts[0])==64}
host = saved_hashes((p/'logs/interleaved-sha256.txt').read_text().splitlines())
logs = (p/'logs/interleaved-confirm.log').read_text().splitlines()
runtime = saved_hashes(logs)
assert runtime['iw-base']==host['iw-final'] and runtime['iw-final']==host['iw-base'] and runtime['iw-control']==host['iw-control']
assert sum(line.startswith("completed and verified round") for line in logs)==12
first_file = p/'interleaved-writes.jsonl'
second_file = p/'interleaved-confirm-wire.jsonl'

def load(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line]

def normalized(rows):
    return [{**r, 'first_in_pair_zero':{'base':'final','final':'base'}[r['first_in_pair_zero']],
            'base_ns':r['final_ns'],'final_ns':r['base_ns']} for r in rows]

first,second=load(first_file),normalized(load(second_file))
fields=('round','mode','operation')
def key(row):return tuple(row[k] for k in fields)
idx={key(r):r for r in first}
assert len(first)==len(second)==len(idx)==48 and set(idx)=={key(r) for r in second}
for r in second:
    assert r['first_in_pair_zero']!=idx[key(r)]['first_in_pair_zero']
    for a in ('base_ns','final_ns'):
        assert len(r[a])==384 and min(r[a])>0
(p/'interleaved-confirm.jsonl').write_text(''.join(json.dumps(r,separators=(',',':'))+'\n' for r in second))

def summarize(rows,campaign):
    table=[]
    for mode in ('memory','btree'):
        for op in ('put','batchput16','delete','batchdelete16'):
            subset=[r for r in rows if r['mode']==mode and r['operation']==op]
            n=len(subset)
            assert n in (6,12)
            row={'campaign':campaign,'mode':mode,'op':op,'rounds':n,'calls_per_arm':384*n}
            for m, fn in [('throughput',mean),('p50',median),('p99',lambda s:sorted(s)[ceil(.99*len(s))-1])]:
                b=[fn(r['base_ns']) for r in subset]
                c=[fn(r['final_ns']) for r in subset]
                ratio=[(x/y-1)*100 if m=='throughput' else (y/x-1)*100 for x,y in zip(b,c)]
                row[m+'_pct']=round(median(ratio),3)
                row[m+'_wins']=sum(y<x for x,y in zip(b,c))
                name='mean' if m=='throughput' else m
                row['base_'+name+'_us']=round(median(b)/1e3,2)
                row['final_'+name+'_us']=round(median(c)/1e3,2)
            row['individual_faster_count']=sum(y<x for r in subset for x,y in zip(r['base_ns'],r['final_ns']))
            table.append(row)
    return table
s1=summarize(first,'first')
s2=summarize(second,'inverted confirmation')
combined=summarize(first+second,'combined')
with (p/'interleaved-combined.csv').open('w', newline='') as f:
    w=csv.DictWriter(f,fieldnames=combined[0].keys());w.writeheader();w.writerows(s1+s2+combined)
lines=[
    '# Confirmation with reversed worker slots','',
    'The second campaign uses the exact same Linux arm64 controller, baseline (357e758), and final (merged.patch) binaries as the first. The Docker command mounts the final binary at /bins/iw-base and the baseline at /bins/iw-final. Both arms independently seed fresh databases with identical keys/values on a new anonymous ext4 volume. The per-call, per-round and process-start order of the actual revisions is therefore inverted relative to the first campaign. The parser verifies the three runtime binary hashes, swaps the two arrays and ordering label, and checks every round and workload matches the opposite original ordering. The archived raw controller output uses the slot names; interleaved-confirm.jsonl uses the actual revision labels.','',
    'Each campaign contains six alternating rounds, one serial caller per DB, a parked cleaner, 384 calls per arm per round and 64-byte values. In total there are 4,608 measured calls per arm and workload, 48 worker databases; each passes count checks, then reopens and verifies 8,192 keys. Public API timing excludes IPC. Throughput deltas below use the median of within-round baseline-mean / final-mean minus one; latency deltas use final / baseline minus one. Positive throughput and negative latency indicate improvement. Wins count independent matched rounds.','',
    '| Index | Op | Throughput first | Confirmation | Combined (wins) | Paired p50 | p99 first | Confirmation | Combined p99 (wins) |',
    '|---|---|---:|---:|---:|---:|---:|---:|---:|']
for a,b,c in zip(s1,s2,combined):
    lines.append(f"| {c['mode']} | {c['op']} | {a['throughput_pct']:+.1f}% | {b['throughput_pct']:+.1f}% | {c['throughput_pct']:+.1f}% ({c['throughput_wins']}/12) | {c['p50_pct']:+.1f}% | {a['p99_pct']:+.1f}% | {b['p99_pct']:+.1f}% | {c['p99_pct']:+.1f}% ({c['p99_wins']}/12) |")
(p/'interleaved-combined.md').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines[6:]))
