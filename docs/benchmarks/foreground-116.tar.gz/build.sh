#!/usr/bin/env bash
set -eu -o pipefail
out=$(cd "$(dirname "$0")" && pwd)
repo=${TARP_REPO:-$(git rev-parse --show-toplevel)}
name=$1
shift
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
git -C "$repo" archive 357e758 | tar -x -C "$tmp"
for p in "$@";do (cd "$tmp" && git apply "$out/patches/$p.patch");done
cp "${TARP_DRIVER:-$out/drivers/api_test.go}" "$tmp/benchmark/foreground_linux_test.go"
docker run --rm --cpus 4 --platform linux/arm64 --network none -e GOMAXPROCS=4 -e GOTOOLCHAIN=local -e GOPROXY=off --mount type=volume,src=tarp-116-buildcache,dst=/root/.cache/go-build -v "$tmp:/src:ro" -v "$out/bins:/out" -w /src "$(cat "$out/image")" go test -buildvcs=false -c -o "/out/$name" ./benchmark
